package ir.shipaa.mobile

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.download.DownloadAction
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.crypto.KeyVault
import ir.shipaa.mobile.data.AppDatabase
import ir.shipaa.mobile.data.AppPrefs
import ir.shipaa.mobile.data.DownloadRepository
import ir.shipaa.mobile.download.DownloadEngine
import ir.shipaa.mobile.download.DownloadOutcome
import ir.shipaa.mobile.player.EncryptedFileDataSource
import kotlinx.coroutines.runBlocking
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import okio.Buffer
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.Random
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

@RunWith(AndroidJUnit4::class)
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class OfflinePipelineTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private lateinit var db: AppDatabase
    private lateinit var dir: File
    private lateinit var repo: DownloadRepository
    private lateinit var server: MockWebServer
    private val video = ByteArray(3 * 1024 * 1024 + 123).also { Random(42).nextBytes(it) }
    private val owner = "owner-a"

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        dir = File(context.cacheDir, "test-videos-${System.nanoTime()}").apply { mkdirs() }
        repo = DownloadRepository(db, dir, AppPrefs(context), LicensePolicy())
        server = MockWebServer().apply { dispatcher = RangeDispatcher(video); start() }
    }

    @After fun tearDown() {
        server.shutdown()
        db.close()
        dir.deleteRecursively()
    }

    /** The engine only accepts dl.shipaa.ir URLs through the bridge; here we rewrite to the mock server. */
    private fun client(): OkHttpClient = OkHttpClient.Builder().addInterceptor { chain ->
        val original = chain.request()
        val target: HttpUrl = server.url(original.url.encodedPath)
        chain.proceed(original.newBuilder().url(target).build())
    }.build()

    private fun info(name: String = "lesson-01.mp4") =
        VideoInfo("https://dl.shipaa.ir/c/$name", "جلسه اول", "دوره", 4821, "https://shipaa.ir/lesson/1/", null)

    @Test fun keystoreWrapsAndUnwrapsFileKeys() {
        val key = ByteArray(32) { it.toByte() }
        val wrapped = KeyVault.wrap(key)
        assertFalse(wrapped.contains(android.util.Base64.encodeToString(key, android.util.Base64.NO_WRAP)))
        assertContentEquals(key, KeyVault.unwrap(wrapped))
        assertNotEquals(wrapped, KeyVault.wrap(key), "random IV per wrap")
    }

    @Test fun interruptedDownloadResumesAndPlaysBackDecrypted() = runBlocking {
        val (id, schedule) = repo.requestDownload(info(), owner)
        assertTrue(schedule)
        repo.transition(id, DownloadAction.START)

        // First attempt: stop after ~1 MB on disk, as if the user paused or the network dropped.
        val file = File(dir, "$id.shv")
        val first = DownloadEngine(repo, client(), freeBytes = { Long.MAX_VALUE })
            .run(id, isStopped = { file.length() > 1_000_000 }) { _, _, _ -> }
        assertEquals(DownloadOutcome.Stopped, first)
        val partial = repo.get(id)!!
        assertTrue(partial.downloadedBytes in 1..video.size.toLong() - 1)
        assertEquals(video.size.toLong(), partial.totalBytes)

        // Second attempt resumes with a Range request from the bytes on disk.
        val second = DownloadEngine(repo, client(), freeBytes = { Long.MAX_VALUE }).run(id, isStopped = { false }) { _, _, _ -> }
        assertEquals(DownloadOutcome.Completed, second)
        val lastRange = server.takeLastRange()
        assertTrue(lastRange.startsWith("bytes=") && !lastRange.startsWith("bytes=0-"), "resume used Range: $lastRange")
        val done = repo.transition(id, DownloadAction.COMPLETE)!!
        assertEquals(DownloadState.COMPLETED, done.stateEnum)

        // The file on disk is encrypted…
        val onDisk = repo.fileFor(done).readBytes()
        assertEquals(video.size, onDisk.size)
        assertFalse(onDisk.copyOfRange(0, 4096).contentEquals(video.copyOfRange(0, 4096)))

        // …and the player's DataSource decrypts it, including from a seek position.
        val source = EncryptedFileDataSource(repo.encryptedFile(done))
        val from = 777_777L
        val len = source.open(DataSpec.Builder().setUri(Uri.parse("shipaa-offline://$id")).setPosition(from).build())
        assertEquals(video.size - from, len)
        val out = ByteArray(len.toInt())
        var n = 0
        while (n < out.size) {
            val r = source.read(out, n, minOf(65_536, out.size - n))
            if (r == C.RESULT_END_OF_INPUT) break
            n += r
        }
        source.close()
        assertContentEquals(video.copyOfRange(from.toInt(), video.size), out)
    }

    @Test fun changedServerFileRestartsFromZero() = runBlocking {
        val (id, _) = repo.requestDownload(info("changing.mp4"), owner)
        repo.transition(id, DownloadAction.START)
        val file = File(dir, "$id.shv")
        DownloadEngine(repo, client(), freeBytes = { Long.MAX_VALUE }).run(id, isStopped = { file.length() > 500_000 }) { _, _, _ -> }
        (server.dispatcher as RangeDispatcher).etag = "\"v2\"" // file replaced on the server
        val outcome = DownloadEngine(repo, client(), freeBytes = { Long.MAX_VALUE }).run(id, isStopped = { false }) { _, _, _ -> }
        assertEquals(DownloadOutcome.Completed, outcome)
        val e = repo.get(id)!!
        val r = repo.encryptedFile(e).reader()
        val all = ByteArray(r.length.toInt())
        var n = 0
        while (n < all.size) { val k = r.read(all, n, all.size - n); if (k < 0) break; n += k }
        r.close()
        assertContentEquals(video, all)
    }

    @Test fun notEnoughSpaceFailsWithoutWriting() = runBlocking {
        val (id, _) = repo.requestDownload(info("big.mp4"), owner)
        repo.transition(id, DownloadAction.START)
        val outcome = DownloadEngine(repo, client(), freeBytes = { 10L * 1024 * 1024 }).run(id, isStopped = { false }) { _, _, _ -> }
        assertIs<DownloadOutcome.Failed>(outcome)
        assertEquals(DownloadError.NO_SPACE, outcome.error)
    }

    @Test fun lessonPageVisitClaimsAndRevivesStoredVideo() = runBlocking {
        val (id, _) = repo.requestDownload(info(), owner)
        repo.transition(id, DownloadAction.START)
        repo.transition(id, DownloadAction.COMPLETE)
        repo.transition(id, DownloadAction.LICENSE_EXPIRED)
        assertEquals(DownloadState.NEEDS_VERIFICATION, repo.get(id)!!.stateEnum)
        repo.markSeenOnPage(listOf(info().src), "owner-b")
        val e = assertNotNull(repo.get(id))
        assertEquals(DownloadState.COMPLETED, e.stateEnum)
        assertEquals("owner-b", e.ownerKey)
        assertEquals(id, VideoUrlPolicy.keyOf(info().src))
    }

    @Test fun progressIsPerAccountAndMergesWithServer() = runBlocking {
        val key = VideoUrlPolicy.keyOf(info().src)
        repo.saveProgress(owner, key, info().src, 120_000, 600_000)
        assertEquals(120_000, repo.progress(owner, key)!!.positionMs)
        assertEquals(null, repo.progress("owner-b", key))
        val dirty = repo.dirtyProgress(owner)
        assertEquals(1, dirty.size)
        val remote = ir.shipaa.mobile.core.progress.WatchProgress(key, 300_000, 600_000, dirty[0].updatedAt + 1000)
        repo.applyRemoteProgress(owner, listOf(remote), dirty.map { it.videoKey }, dirty[0].updatedAt)
        assertEquals(300_000, repo.progress(owner, key)!!.positionMs)
        assertTrue(repo.dirtyProgress(owner).isEmpty())
    }
}

/** Serves [body] with ETag and correct 206 / If-Range semantics. */
private class RangeDispatcher(private val body: ByteArray) : Dispatcher() {
    @Volatile var etag = "\"v1\""
    val ranges = mutableListOf<String>()

    override fun dispatch(request: RecordedRequest): MockResponse {
        val range = request.getHeader("Range")
        synchronized(ranges) { ranges += range ?: "" }
        val ifRange = request.getHeader("If-Range")
        val full = MockResponse().setResponseCode(200).setHeader("ETag", etag)
            .setHeader("Content-Type", "video/mp4").setBody(Buffer().write(body))
        if (range == null || (ifRange != null && ifRange != etag)) return full
        val start = range.removePrefix("bytes=").substringBefore('-').toInt()
        if (start >= body.size) return MockResponse().setResponseCode(416)
        return MockResponse().setResponseCode(206).setHeader("ETag", etag)
            .setHeader("Content-Range", "bytes $start-${body.size - 1}/${body.size}")
            .setHeader("Content-Type", "video/mp4")
            .setBody(Buffer().write(body, start, body.size - start))
    }
}

private fun MockWebServer.takeLastRange(): String =
    (dispatcher as RangeDispatcher).ranges.let { synchronized(it) { it.last() } }

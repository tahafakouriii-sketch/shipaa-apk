package ir.shipaa.mobile.core.text

/** Persian presentation helpers used everywhere in the UI. */
object PersianFormat {
    private const val PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"

    fun digits(input: String): String = buildString(input.length) {
        for (ch in input) append(if (ch in '0'..'9') PERSIAN_DIGITS[ch - '0'] else ch)
    }

    fun number(n: Long): String = digits(n.toString())
    fun number(n: Int): String = digits(n.toString())

    /** 1.5 گیگابایت / 340 مگابایت / 820 کیلوبایت, Persian digits and decimal separator. */
    fun bytes(n: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        val text = when {
            n >= gb -> one(n / gb) + " گیگابایت"
            n >= mb -> (if (n >= 100 * mb) "%.0f".format(java.util.Locale.US, n / mb) else one(n / mb)) + " مگابایت"
            n >= kb -> "%.0f".format(java.util.Locale.US, n / kb) + " کیلوبایت"
            else -> "$n بایت"
        }
        return digits(text).replace('.', '٫')
    }

    private fun one(v: Double): String {
        val s = "%.1f".format(java.util.Locale.US, v)
        return if (s.endsWith(".0")) s.dropLast(2) else s
    }

    /** 1:05:09 or 12:04 with Persian digits. */
    fun duration(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        val text = if (h > 0) "%d:%02d:%02d".format(java.util.Locale.US, h, m, s) else "%d:%02d".format(java.util.Locale.US, m, s)
        return digits(text)
    }

    fun percent(p: Int): String = digits(p.coerceIn(0, 100).toString()) + "٪"
}

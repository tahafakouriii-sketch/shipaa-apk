package ir.shipaa.mobile.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Whether the device has a network with internet capability.
 *
 * Deliberately NOT based on NET_CAPABILITY_VALIDATED: Android validates through Google
 * connectivity-check servers, which are often unreachable from Iran even when shipaa.ir works.
 * Real reachability is decided by the actual request (WebView error / HTTP result).
 */
class Connectivity(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val _online = MutableStateFlow(currentlyOnline())
    val online: StateFlow<Boolean> = _online.asStateFlow()

    init {
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { _online.value = true }
                override fun onLost(network: Network) { _online.value = currentlyOnline() }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    _online.value = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                }
            })
        } catch (_: Exception) { /* keep the initial value */ }
    }

    /** True for mobile data / metered hotspots (used by the "Wi-Fi only" setting). */
    fun isMetered(): Boolean = try { cm.isActiveNetworkMetered } catch (_: Exception) { true }

    fun currentlyOnline(): Boolean = try {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }
}

package ir.shipaa.mobile.core.download

/** Persisted lifecycle of a stored video. Names are stored in the database; never rename. */
enum class DownloadState {
    QUEUED, WAITING_NETWORK, DOWNLOADING, PAUSED, FAILED, COMPLETED, NEEDS_VERIFICATION, LOCKED;

    val isActive: Boolean get() = this == QUEUED || this == WAITING_NETWORK || this == DOWNLOADING
    val isPlayableOffline: Boolean get() = this == COMPLETED

    companion object {
        fun parse(name: String?): DownloadState = entries.firstOrNull { it.name == name } ?: FAILED
    }
}

enum class DownloadError(val retryable: Boolean) {
    NETWORK(true),
    SERVER(true),
    BAD_RESPONSE(false),
    NOT_FOUND(false),
    SESSION_EXPIRED(false),
    NO_SPACE(false),
    STORAGE_IO(false),
    TOO_LARGE(false),
    /** The site no longer shows this lesson to the user (refund, expiry, removal). */
    ACCESS_REVOKED(false),
    /** The device key could not decrypt the stored file (e.g. keystore reset); download again. */
    KEY_LOST(false),
    UNKNOWN(true);

    companion object {
        fun parse(name: String?): DownloadError? = entries.firstOrNull { it.name == name }
    }
}

enum class DownloadAction { ENQUEUE, START, PROGRESS, PAUSE, RESUME, NETWORK_LOST, FAIL, COMPLETE, LICENSE_EXPIRED, VERIFIED, LOCK, UNLOCK }

/**
 * Legal state transitions. Anything not listed keeps the current state, which makes
 * late or duplicated worker callbacks harmless (e.g. PROGRESS after PAUSE).
 */
object DownloadStateMachine {
    fun next(current: DownloadState, action: DownloadAction): DownloadState = when (action) {
        DownloadAction.ENQUEUE, DownloadAction.RESUME -> when (current) {
            DownloadState.PAUSED, DownloadState.FAILED, DownloadState.WAITING_NETWORK, DownloadState.QUEUED -> DownloadState.QUEUED
            else -> current
        }
        DownloadAction.START -> if (current == DownloadState.QUEUED || current == DownloadState.WAITING_NETWORK) DownloadState.DOWNLOADING else current
        DownloadAction.PROGRESS -> if (current == DownloadState.DOWNLOADING || current == DownloadState.QUEUED) DownloadState.DOWNLOADING else current
        DownloadAction.PAUSE -> if (current.isActive || current == DownloadState.FAILED) DownloadState.PAUSED else current
        DownloadAction.NETWORK_LOST -> if (current.isActive) DownloadState.WAITING_NETWORK else current
        DownloadAction.FAIL -> if (current.isActive) DownloadState.FAILED else current
        DownloadAction.COMPLETE -> if (current.isActive) DownloadState.COMPLETED else current
        DownloadAction.LICENSE_EXPIRED -> if (current == DownloadState.COMPLETED) DownloadState.NEEDS_VERIFICATION else current
        DownloadAction.VERIFIED -> if (current == DownloadState.NEEDS_VERIFICATION) DownloadState.COMPLETED else current
        DownloadAction.LOCK -> if (current == DownloadState.COMPLETED || current == DownloadState.NEEDS_VERIFICATION) DownloadState.LOCKED else current
        DownloadAction.UNLOCK -> if (current == DownloadState.LOCKED) DownloadState.NEEDS_VERIFICATION else current
    }
}

/** Visual presentation of a state, shared by the library screen and the injected web bar. */
enum class StatusTone { SUCCESS, PROGRESS, NEUTRAL, WARNING, DANGER, LOCKED }

data class StatusPresentation(val label: String, val tone: StatusTone, val icon: String)

object DownloadPresentation {
    fun of(state: DownloadState, error: DownloadError? = null): StatusPresentation = when (state) {
        DownloadState.COMPLETED -> StatusPresentation("آماده پخش آفلاین", StatusTone.SUCCESS, "check")
        DownloadState.DOWNLOADING -> StatusPresentation("در حال دانلود", StatusTone.PROGRESS, "download")
        DownloadState.QUEUED -> StatusPresentation("در صف دانلود", StatusTone.NEUTRAL, "queue")
        DownloadState.WAITING_NETWORK -> if (error == DownloadError.SERVER)
            StatusPresentation("خطای سرور — تلاش خودکار دوباره", StatusTone.NEUTRAL, "retry")
        else StatusPresentation("منتظر اینترنت", StatusTone.NEUTRAL, "wifi_off")
        DownloadState.PAUSED -> StatusPresentation("دانلود ناقص — متوقف‌شده", StatusTone.WARNING, "pause")
        DownloadState.FAILED -> StatusPresentation(errorLabel(error), StatusTone.DANGER, "error")
        DownloadState.NEEDS_VERIFICATION -> StatusPresentation("نیاز به تأیید با اینترنت", StatusTone.LOCKED, "verify")
        DownloadState.LOCKED -> if (error == DownloadError.ACCESS_REVOKED)
            StatusPresentation("دسترسی به این جلسه فعال نیست", StatusTone.LOCKED, "lock")
        else StatusPresentation("قفل — مربوط به حساب دیگر", StatusTone.LOCKED, "lock")
    }

    fun errorLabel(error: DownloadError?): String = when (error) {
        DownloadError.NETWORK -> "قطع اینترنت — دوباره تلاش کنید"
        DownloadError.SERVER -> "خطای سرور — بعداً تلاش کنید"
        DownloadError.NOT_FOUND -> "فایل در سرور پیدا نشد"
        DownloadError.SESSION_EXPIRED -> "نشست منقضی شده — دوباره وارد شوید"
        DownloadError.NO_SPACE -> "فضای خالی گوشی کافی نیست"
        DownloadError.STORAGE_IO -> "خطای ذخیره‌سازی روی گوشی"
        DownloadError.TOO_LARGE -> "حجم فایل بیش از حد مجاز است"
        DownloadError.BAD_RESPONSE -> "پاسخ نامعتبر سرور — دانلود متوقف شد"
        DownloadError.ACCESS_REVOKED -> "دسترسی به این جلسه فعال نیست"
        DownloadError.KEY_LOST -> "فایل ذخیره‌شده قابل بازکردن نیست — دوباره دانلود کنید"
        DownloadError.UNKNOWN, null -> "دانلود ناقص ماند"
    }

    /** Whole-number percent; never reports 100 before the download is complete. */
    fun percent(done: Long, total: Long, completed: Boolean): Int {
        if (completed) return 100
        if (total <= 0 || done <= 0) return 0
        return ((done * 100) / total).toInt().coerceIn(0, 99)
    }
}

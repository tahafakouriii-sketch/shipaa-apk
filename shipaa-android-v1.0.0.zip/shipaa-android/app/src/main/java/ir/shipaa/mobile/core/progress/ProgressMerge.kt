package ir.shipaa.mobile.core.progress

/** A watch position for one video. */
data class WatchProgress(
    val videoKey: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
) {
    val fraction: Float get() = if (durationMs <= 0) 0f else (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
}

object ProgressPolicy {
    /** Within this distance of the end a lesson counts as finished and restarts from 0. */
    const val END_MARGIN_MS = 15_000L
    /** Positions this close to the start are not worth resuming. */
    const val MIN_RESUME_MS = 5_000L

    fun resumePosition(p: WatchProgress?): Long {
        if (p == null) return 0
        if (p.positionMs < MIN_RESUME_MS) return 0
        if (p.durationMs > 0 && p.durationMs - p.positionMs <= END_MARGIN_MS) return 0
        return p.positionMs
    }

    fun isFinished(p: WatchProgress?): Boolean =
        p != null && p.durationMs > 0 && p.durationMs - p.positionMs <= END_MARGIN_MS

    /** Latest update wins; on a tie the further position wins. */
    fun merge(local: WatchProgress?, remote: WatchProgress?): WatchProgress? = when {
        local == null -> remote
        remote == null -> local
        remote.updatedAt > local.updatedAt -> remote
        remote.updatedAt < local.updatedAt -> local
        else -> if (remote.positionMs > local.positionMs) remote else local
    }
}

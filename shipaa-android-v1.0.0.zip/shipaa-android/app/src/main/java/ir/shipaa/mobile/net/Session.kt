package ir.shipaa.mobile.net

import ir.shipaa.mobile.core.identity.WpIdentity
import ir.shipaa.mobile.data.AppPrefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The current account, as far as the device can tell (online or offline). */
data class Account(val ownerKey: String, val username: String, val fromLiveCookie: Boolean)

class Session(private val prefs: AppPrefs) {
    private val _account = MutableStateFlow(restore())
    val account: StateFlow<Account?> = _account.asStateFlow()

    private fun restore(): Account? {
        val key = prefs.lastOwnerKey ?: return null
        return Account(key, prefs.lastUsername ?: "", fromLiveCookie = false)
    }

    /** Re-reads the WordPress login cookie. Call after page loads and on resume. */
    fun refresh(nowMs: Long = System.currentTimeMillis()): Account? {
        val id = WpIdentity.fromCookieHeader(Http.siteCookies(), nowMs / 1000)
        if (id != null) {
            val acc = Account(id.ownerKey, id.username, fromLiveCookie = true)
            prefs.lastOwnerKey = acc.ownerKey
            prefs.lastUsername = acc.username
            _account.value = acc
            return acc
        }
        // No live cookie: it may have expired while offline. Keep the last account until an
        // explicit logout is observed (see markLoggedOut), so the offline library stays usable.
        val kept = restore()
        _account.value = kept
        return kept
    }

    /** Called when the user signs out on the site (logout URL observed). */
    fun markLoggedOut() {
        prefs.lastOwnerKey = null
        prefs.lastUsername = null
        _account.value = null
    }

    val ownerKey: String? get() = _account.value?.ownerKey

    companion object {
        /** WooCommerce / WordPress logout URLs. */
        fun isLogoutUrl(url: String?): Boolean {
            val u = url ?: return false
            return u.contains("customer-logout") || (u.contains("wp-login.php") && u.contains("action=logout"))
        }
    }
}

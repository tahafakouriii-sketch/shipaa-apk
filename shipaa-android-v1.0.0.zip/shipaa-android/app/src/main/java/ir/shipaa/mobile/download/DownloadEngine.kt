package ir.shipaa.mobile.download

import android.os.StatFs
import android.os.SystemClock
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.RangeDecision
import ir.shipaa.mobile.core.download.RangeResponsePolicy
import ir.shipaa.mobile.core.download.StoragePolicy
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.data.DownloadRepository
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.security.GeneralSecurityException

sealed interface DownloadOutcome {
    data object Completed : DownloadOutcome
    /** The worker was stopped (pause, cancel, or system constraints). Bytes so far are kept. */
    data object Stopped : DownloadOutcome
    data class Failed(val error: DownloadError) : DownloadOutcome
}

/**
 * Downloads one lesson into its encrypted file, resuming from the bytes already on disk.
 * Blocking I/O: call from Dispatchers.IO.
 */
class DownloadEngine(
    private val repo: DownloadRepository,
    private val client: OkHttpClient,
    private val freeBytes: (File) -> Long = { dir -> StatFs(dir.path).availableBytes },
) {
    suspend fun run(
        id: String,
        isStopped: () -> Boolean,
        onProgress: suspend (entity: DownloadEntity, done: Long, total: Long) -> Unit,
    ): DownloadOutcome {
        var entity = repo.get(id) ?: return DownloadOutcome.Stopped
        val file = try {
            repo.encryptedFile(entity)
        } catch (_: GeneralSecurityException) {
            return DownloadOutcome.Failed(DownloadError.KEY_LOST)
        } catch (_: IllegalArgumentException) {
            return DownloadOutcome.Failed(DownloadError.KEY_LOST)
        }
        val dir = repo.fileFor(entity).parentFile ?: return DownloadOutcome.Failed(DownloadError.STORAGE_IO)
        dir.mkdirs()

        var restarts = 0
        while (true) {
            if (isStopped()) return DownloadOutcome.Stopped
            val knownTotal = entity.totalBytes.takeIf { it > 0 }
            var offset = file.length
            if (knownTotal != null && offset > knownTotal) { file.truncate(); offset = 0 }
            if (knownTotal != null && offset == knownTotal) return DownloadOutcome.Completed

            when (StoragePolicy.check(knownTotal, offset, safeFree(dir))) {
                is StoragePolicy.Check.NotEnoughSpace -> return DownloadOutcome.Failed(DownloadError.NO_SPACE)
                StoragePolicy.Check.TooLarge -> return DownloadOutcome.Failed(DownloadError.TOO_LARGE)
                StoragePolicy.Check.Ok -> Unit
            }

            val validator = entity.etag?.takeUnless { it.startsWith("W/") } ?: entity.lastModified
            val request = Request.Builder()
                .url(entity.videoUrl)
                .header("Accept-Encoding", "identity") // byte offsets must match the file
                .header("Range", "bytes=$offset-")
                .apply { if (offset > 0 && validator != null) header("If-Range", validator) }
                .build()

            val response = try {
                client.newCall(request).execute()
            } catch (_: IOException) {
                return DownloadOutcome.Failed(DownloadError.NETWORK)
            }

            response.use { resp ->
                val body = resp.body ?: return DownloadOutcome.Failed(DownloadError.BAD_RESPONSE)
                val decision = RangeResponsePolicy.decide(
                    status = resp.code,
                    contentRange = resp.header("Content-Range"),
                    contentLength = body.contentLength(),
                    requestedFrom = offset,
                    expectedTotal = knownTotal,
                )
                val etag = resp.header("ETag")
                val lastModified = resp.header("Last-Modified")
                if (decision is RangeDecision.Fail) return DownloadOutcome.Failed(decision.reason)
                if (decision == RangeDecision.AlreadyComplete) return DownloadOutcome.Completed
                if (decision is RangeDecision.Restart) {
                    file.truncate()
                    if (resp.code != 200) {
                        // The file changed on the server (different size): request it again from 0.
                        if (++restarts > MAX_RESTARTS) return DownloadOutcome.Failed(DownloadError.BAD_RESPONSE)
                        repo.saveValidators(id, 0, null, null)
                        entity = repo.get(id) ?: return DownloadOutcome.Stopped
                        return@use // next loop iteration
                    }
                }
                val total: Long = when (decision) {
                    is RangeDecision.Append -> decision.total
                    is RangeDecision.Restart -> decision.total ?: -1L
                    else -> return DownloadOutcome.Failed(DownloadError.BAD_RESPONSE)
                }
                repo.saveValidators(id, total.coerceAtLeast(0), etag, lastModified)
                entity = repo.get(id) ?: return DownloadOutcome.Stopped

                if (total > 0) {
                    val check = StoragePolicy.check(total, file.length, safeFree(dir))
                    if (check is StoragePolicy.Check.NotEnoughSpace) return DownloadOutcome.Failed(DownloadError.NO_SPACE)
                    if (check == StoragePolicy.Check.TooLarge) return DownloadOutcome.Failed(DownloadError.TOO_LARGE)
                }

                val input = body.byteStream()
                val buffer = ByteArray(BUFFER)
                file.appender().use { out ->
                    var lastReport = 0L
                    var lastSync = out.offset
                    while (true) {
                        if (isStopped()) {
                            out.sync()
                            repo.updateProgress(id, out.offset, total.coerceAtLeast(0))
                            return DownloadOutcome.Stopped
                        }
                        val n = try {
                            input.read(buffer)
                        } catch (_: IOException) {
                            out.sync()
                            repo.updateProgress(id, out.offset, total.coerceAtLeast(0))
                            return DownloadOutcome.Failed(DownloadError.NETWORK)
                        }
                        if (n < 0) break
                        try {
                            out.write(buffer, 0, n)
                        } catch (io: IOException) {
                            return DownloadOutcome.Failed(if (isNoSpace(io)) DownloadError.NO_SPACE else DownloadError.STORAGE_IO)
                        }
                        if (out.offset - lastSync >= SYNC_EVERY) { out.sync(); lastSync = out.offset }
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastReport >= REPORT_EVERY_MS) {
                            lastReport = now
                            repo.updateProgress(id, out.offset, total.coerceAtLeast(0))
                            onProgress(entity, out.offset, total)
                        }
                    }
                    out.sync()
                }

                val finalLength = file.length
                return when {
                    total <= 0 -> {
                        if (finalLength <= 0) return DownloadOutcome.Failed(DownloadError.BAD_RESPONSE)
                        repo.saveValidators(id, finalLength, etag, lastModified)
                        repo.updateProgress(id, finalLength, finalLength)
                        DownloadOutcome.Completed
                    }
                    finalLength == total -> { repo.updateProgress(id, finalLength, total); DownloadOutcome.Completed }
                    // Connection closed early: keep the bytes and resume on the next attempt.
                    finalLength < total -> { repo.updateProgress(id, finalLength, total); DownloadOutcome.Failed(DownloadError.NETWORK) }
                    else -> { file.truncate(); DownloadOutcome.Failed(DownloadError.BAD_RESPONSE) }
                }
            }
        }
    }

    private fun safeFree(dir: File): Long = try { freeBytes(dir) } catch (_: Exception) { Long.MAX_VALUE }

    private fun isNoSpace(e: IOException): Boolean {
        val m = (e.message ?: "") + (e.cause?.message ?: "")
        return m.contains("ENOSPC") || m.contains("No space left", ignoreCase = true)
    }

    private companion object {
        const val BUFFER = 64 * 1024
        const val SYNC_EVERY = 4L * 1024 * 1024
        const val REPORT_EVERY_MS = 700L
        const val MAX_RESTARTS = 2
    }
}

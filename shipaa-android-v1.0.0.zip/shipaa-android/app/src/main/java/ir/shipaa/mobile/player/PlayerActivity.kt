package ir.shipaa.mobile.player

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.progress.ProgressPolicy
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.library.LibraryActivity
import ir.shipaa.mobile.net.Http
import ir.shipaa.mobile.sync.ProgressSyncWorker
import ir.shipaa.mobile.ui.components.ButtonKind
import ir.shipaa.mobile.ui.components.ProgressLine
import ir.shipaa.mobile.ui.components.ShipaaButton
import ir.shipaa.mobile.ui.components.StatusChip
import ir.shipaa.mobile.ui.theme.ShipaaColors
import ir.shipaa.mobile.ui.theme.ShipaaTheme
import ir.shipaa.mobile.web.MainActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Native Media3 player for lessons, online or from the encrypted offline copy.
 * Portrait: video on top and lesson details below. Landscape: immersive full screen.
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class PlayerActivity : ComponentActivity() {

    sealed interface Status {
        data object Loading : Status
        data class Playing(val offline: Boolean) : Status
        data class Blocked(val title: String, val message: String) : Status
        data class Error(val message: String) : Status
    }

    private var player: ExoPlayer? = null
    private lateinit var video: VideoInfo
    private lateinit var videoKey: String
    private var ownerKey: String? = null
    private var username: String = ""
    private val status = MutableStateFlow<Status>(Status.Loading)

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> download() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        AppGraph.ensure(this)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        video = readVideo(intent) ?: run { finish(); return }
        videoKey = VideoUrlPolicy.keyOf(video.src)
        val account = AppGraph.session.refresh()
        ownerKey = account?.ownerKey
        username = account?.username.orEmpty()

        val exo = ExoPlayer.Builder(this)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = exo
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            override fun onPlayerError(error: PlaybackException) {
                val offline = (status.value as? Status.Playing)?.offline == true
                status.value = Status.Error(
                    if (offline) "پخش فایل ذخیره‌شده با خطا روبه‌رو شد. اگر تکرار شد، ویدئو را حذف و دوباره ذخیره کنید."
                    else "پخش آنلاین قطع شد. اتصال اینترنت را بررسی کنید و دوباره تلاش کنید."
                )
            }
        })

        setContent {
            ShipaaTheme {
                PlayerScreen(
                    activity = this,
                    exo = exo,
                    video = video,
                    watermark = username,
                )
            }
        }

        lifecycleScope.launch { prepare() }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(5_000)
                    if (player?.isPlaying == true) saveProgress()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val next = readVideo(intent) ?: return
        if (next.src == video.src) return
        lifecycleScope.launch {
            saveProgress()
            setIntent(intent)
            recreate()
        }
    }

    internal fun prepareAgain() { lifecycleScope.launch { prepare() } }

    private suspend fun prepare() {
        status.value = Status.Loading
        val exo = player ?: return
        val owner = ownerKey
        val resume = owner?.let { ProgressPolicy.resumePosition(AppGraph.repo.progress(it, videoKey)) } ?: 0L
        when (val plan = PlaybackPlanner.plan(video, owner)) {
            is PlaybackPlan.Offline -> {
                val source = ProgressiveMediaSource.Factory(EncryptedFileDataSource.Factory(plan.file))
                    .createMediaSource(MediaItem.fromUri("shipaa-offline://${plan.entity.id}"))
                exo.setMediaSource(source, resume)
                exo.prepare()
                exo.playWhenReady = true
                status.value = Status.Playing(offline = true)
            }
            is PlaybackPlan.Online -> {
                val source = ProgressiveMediaSource.Factory(OkHttpDataSource.Factory(Http.client()))
                    .createMediaSource(MediaItem.fromUri(plan.url))
                exo.setMediaSource(source, resume)
                exo.prepare()
                exo.playWhenReady = true
                status.value = Status.Playing(offline = false)
            }
            is PlaybackPlan.Blocked -> status.value = Status.Blocked(plan.title, plan.message)
        }
    }

    private suspend fun saveProgress() {
        val exo = player ?: return
        val owner = ownerKey ?: return
        val duration = exo.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
        AppGraph.repo.saveProgress(owner, videoKey, video.src, exo.currentPosition, duration)
    }

    internal fun setFullscreen(full: Boolean) {
        requestedOrientation = if (full) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    internal fun applyImmersive(landscape: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (landscape) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    internal fun requestDownload() {
        if (Build.VERSION.SDK_INT >= 33 && !AppGraph.prefs.notificationPermissionAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            AppGraph.prefs.notificationPermissionAsked = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            download()
        }
    }

    private fun download() {
        val owner = AppGraph.session.refresh()?.takeIf { it.fromLiveCookie }?.ownerKey
        if (owner == null) { toast("برای ذخیره جلسه، ابتدا وارد حساب کاربری شوید"); return }
        lifecycleScope.launch {
            AppGraph.scheduler.enqueue(video, owner)
            toast("به صف ذخیره آفلاین اضافه شد")
        }
    }

    internal fun pauseDownload() { lifecycleScope.launch { AppGraph.scheduler.pause(videoKey) } }
    internal fun resumeDownload() { lifecycleScope.launch { AppGraph.scheduler.resume(videoKey) } }
    internal fun openLibrary() = startActivity(Intent(this, LibraryActivity::class.java))
    internal fun openLessonPage() {
        if (video.pageUrl.isNotBlank()) { MainActivity.open(this, video.pageUrl); finish() }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    override fun onStop() {
        super.onStop()
        player?.pause()
        lifecycleScope.launch {
            saveProgress()
            ProgressSyncWorker.request(applicationContext)
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    internal val statusFlow get() = status

    companion object {
        private const val EXTRA_SRC = "src"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_COURSE = "course"
        private const val EXTRA_LESSON = "lesson"
        private const val EXTRA_PAGE = "page"
        private const val EXTRA_POSTER = "poster"

        fun createIntent(context: Context, v: VideoInfo): Intent = Intent(context, PlayerActivity::class.java)
            .putExtra(EXTRA_SRC, v.src).putExtra(EXTRA_TITLE, v.title).putExtra(EXTRA_COURSE, v.course)
            .putExtra(EXTRA_LESSON, v.lessonId ?: 0L).putExtra(EXTRA_PAGE, v.pageUrl).putExtra(EXTRA_POSTER, v.poster)

        private fun readVideo(i: Intent?): VideoInfo? {
            val src = VideoUrlPolicy.normalize(i?.getStringExtra(EXTRA_SRC)) ?: return null
            return VideoInfo(
                src = src,
                title = i?.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: VideoUrlPolicy.fallbackTitle(src),
                course = i?.getStringExtra(EXTRA_COURSE).orEmpty(),
                lessonId = i?.getLongExtra(EXTRA_LESSON, 0L)?.takeIf { it > 0 },
                pageUrl = i?.getStringExtra(EXTRA_PAGE).orEmpty(),
                poster = i?.getStringExtra(EXTRA_POSTER),
            )
        }
    }
}

@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
@kotlin.OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayerScreen(activity: PlayerActivity, exo: ExoPlayer, video: VideoInfo, watermark: String) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val status by activity.statusFlow.collectAsState()
    val entity by remember { AppGraph.repo.observe(VideoUrlPolicy.keyOf(video.src)) }.collectAsState(initial = null)
    val online by AppGraph.connectivity.online.collectAsState()
    LaunchedEffect(landscape) { activity.applyImmersive(landscape) }

    val surface: @Composable (Modifier) -> Unit = { modifier ->
        Box(modifier.background(ShipaaColors.player), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exo
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        setShowNextButton(false)
                        setShowPreviousButton(false)
                        setShowSubtitleButton(false)
                        keepScreenOn = false
                        setFullscreenButtonClickListener { full -> activity.setFullscreen(full) }
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            if (watermark.isNotBlank()) Watermark(watermark)
            when (val s = status) {
                PlayerActivity.Status.Loading -> CircularProgressIndicator(color = Color.White)
                is PlayerActivity.Status.Blocked -> Overlay(s.title, s.message, Icons.Rounded.Lock) {
                    ShipaaButton("کتابخانه من", activity::openLibrary, icon = Icons.Rounded.VideoLibrary)
                }
                is PlayerActivity.Status.Error -> Overlay("پخش متوقف شد", s.message, Icons.Rounded.Refresh) {
                    ShipaaButton("تلاش دوباره", activity::prepareAgain, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Refresh)
                }
                is PlayerActivity.Status.Playing -> Unit
            }
        }
    }

    if (landscape) {
        surface(Modifier.fillMaxSize())
        return
    }

    Column(Modifier.fillMaxSize().background(ShipaaColors.background)) {
        Box(Modifier.background(ShipaaColors.player).statusBarsPadding()) {
            surface(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            IconButton(onClick = { activity.finish() }, modifier = Modifier.align(Alignment.TopStart)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(DesignTokens.Space.md.dp),
            verticalArrangement = Arrangement.spacedBy(DesignTokens.Space.sm.dp),
        ) {
            if (video.course.isNotBlank()) Text(video.course, style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
            Text(video.title, style = MaterialTheme.typography.titleLarge, color = ShipaaColors.ink)
            val s = status
            if (s is PlayerActivity.Status.Playing) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (s.offline) Icons.Rounded.CloudDone else Icons.Rounded.Wifi, null,
                        tint = if (s.offline) ShipaaColors.success else ShipaaColors.sky, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (s.offline) "در حال پخش از نسخه ذخیره‌شده روی گوشی" else "پخش آنلاین",
                        style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
                }
            }
            val e = entity
            if (e != null) {
                StatusChip(e.stateEnum, e.errorEnum, e.percent)
                if (e.stateEnum.isActive || e.stateEnum == DownloadState.PAUSED) {
                    ProgressLine(if (e.totalBytes > 0) e.downloadedBytes.toFloat() / e.totalBytes else 0f)
                    Text("${PersianFormat.bytes(e.downloadedBytes)} از ${PersianFormat.bytes(e.totalBytes)}",
                        style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (e?.stateEnum) {
                    null, DownloadState.FAILED, DownloadState.LOCKED, DownloadState.NEEDS_VERIFICATION ->
                        ShipaaButton("ذخیره برای آفلاین", activity::requestDownload, kind = ButtonKind.PRIMARY,
                            icon = Icons.Rounded.Download, enabled = online)
                    DownloadState.DOWNLOADING, DownloadState.QUEUED, DownloadState.WAITING_NETWORK ->
                        ShipaaButton("توقف دانلود", activity::pauseDownload, icon = Icons.Rounded.Pause)
                    DownloadState.PAUSED ->
                        ShipaaButton("ادامه دانلود", activity::resumeDownload, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Download, enabled = online)
                    DownloadState.COMPLETED -> Unit
                }
                ShipaaButton("کتابخانه من", activity::openLibrary, icon = Icons.Rounded.VideoLibrary)
                if (video.pageUrl.isNotBlank() && online) ShipaaButton("صفحه جلسه", activity::openLessonPage, icon = Icons.Rounded.Link)
            }
            Text(
                "ویدئوهای ذخیره‌شده رمزگذاری می‌شوند و فقط داخل اپ شیپا و با حساب خودتان قابل پخش‌اند.",
                style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
            )
        }
    }
}


@Composable
private fun Overlay(title: String, message: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(ShipaaColors.player.copy(alpha = 0.92f)).padding(DesignTokens.Space.lg.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(32.dp))
        Spacer(Modifier.size(8.dp))
        Text(title, style = MaterialTheme.typography.titleSmall, color = Color.White, textAlign = TextAlign.Center)
        Text(message, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
        Spacer(Modifier.size(12.dp))
        action()
    }
}

/** Faint user name that moves every 20 s: discourages filming the screen. */
@Composable
private fun Watermark(text: String) {
    var corner by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(20_000); corner = (corner + 1) % 4 } }
    val alpha by animateFloatAsState(0.22f, tween(600), label = "wm")
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val x = if (corner % 2 == 0) maxWidth * 0.08f else maxWidth * 0.55f
        val y = if (corner < 2) maxHeight * 0.12f else maxHeight * 0.72f
        Text(
            text,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.offset(x, y).alpha(alpha),
        )
    }
}

package ir.shipaa.mobile.core.download

/** Device storage checks before and during a download. */
object StoragePolicy {
    /** Keep this much free space for the system and other apps. */
    const val SAFETY_MARGIN_BYTES = 200L * 1024 * 1024
    /** Upper bound for one lesson file; protects against wrong URLs. */
    const val MAX_FILE_BYTES = 8L * 1024 * 1024 * 1024

    sealed interface Check {
        data object Ok : Check
        data class NotEnoughSpace(val neededBytes: Long, val freeBytes: Long) : Check
        data object TooLarge : Check
    }

    fun check(totalBytes: Long?, alreadyDownloaded: Long, freeBytes: Long): Check {
        if (totalBytes != null && totalBytes > MAX_FILE_BYTES) return Check.TooLarge
        val remaining = if (totalBytes == null) 0L else (totalBytes - alreadyDownloaded).coerceAtLeast(0)
        val needed = remaining + SAFETY_MARGIN_BYTES
        return if (freeBytes >= needed) Check.Ok else Check.NotEnoughSpace(needed, freeBytes)
    }
}

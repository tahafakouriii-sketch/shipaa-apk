package ir.shipaa.mobile.core.download

/** Parsed `Content-Range: bytes start-end/total`. */
data class ContentRange(val start: Long, val end: Long, val total: Long) {
    val length: Long get() = end - start + 1

    companion object {
        private val pattern = Regex("""^\s*bytes\s+(\d+)-(\d+)/(\d+)\s*$""", RegexOption.IGNORE_CASE)

        fun parse(header: String?): ContentRange? {
            val m = pattern.matchEntire(header ?: return null) ?: return null
            val start = m.groupValues[1].toLongOrNull() ?: return null
            val end = m.groupValues[2].toLongOrNull() ?: return null
            val total = m.groupValues[3].toLongOrNull() ?: return null
            if (start < 0 || end < start || total <= end) return null
            return ContentRange(start, end, total)
        }
    }
}

/** What to do with an HTTP response to a (possibly ranged) download request. */
sealed interface RangeDecision {
    /** Append the body at [offset]. [total] is the full file size. */
    data class Append(val offset: Long, val total: Long) : RangeDecision
    /** The server ignored Range or the file changed: truncate the local file and write from 0. */
    data class Restart(val total: Long?) : RangeDecision
    /** Local copy already holds the whole file. */
    data object AlreadyComplete : RangeDecision
    data class Fail(val reason: DownloadError) : RangeDecision
}

object RangeResponsePolicy {
    /**
     * @param requestedFrom the byte offset sent in `Range: bytes=N-` (0 for a fresh download)
     * @param expectedTotal size recorded from an earlier response, if any
     */
    fun decide(
        status: Int,
        contentRange: String?,
        contentLength: Long?,
        requestedFrom: Long,
        expectedTotal: Long?,
    ): RangeDecision = when (status) {
        206 -> {
            val range = ContentRange.parse(contentRange)
            when {
                range == null -> RangeDecision.Fail(DownloadError.BAD_RESPONSE)
                range.start != requestedFrom -> RangeDecision.Fail(DownloadError.BAD_RESPONSE)
                range.end != range.total - 1 -> RangeDecision.Fail(DownloadError.BAD_RESPONSE)
                expectedTotal != null && expectedTotal != range.total -> RangeDecision.Restart(range.total)
                contentLength != null && contentLength >= 0 && contentLength != range.length ->
                    RangeDecision.Fail(DownloadError.BAD_RESPONSE)
                else -> RangeDecision.Append(range.start, range.total)
            }
        }
        // A full body: either a fresh download, or If-Range told us the file changed.
        200 -> RangeDecision.Restart(contentLength?.takeIf { it > 0 })
        416 -> if (expectedTotal != null && requestedFrom >= expectedTotal) RangeDecision.AlreadyComplete
               else RangeDecision.Restart(null)
        401, 403 -> RangeDecision.Fail(DownloadError.SESSION_EXPIRED)
        404, 410 -> RangeDecision.Fail(DownloadError.NOT_FOUND)
        in 500..599, 408, 429 -> RangeDecision.Fail(DownloadError.SERVER)
        else -> RangeDecision.Fail(DownloadError.BAD_RESPONSE)
    }
}

package ir.shipaa.mobile.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.shipaa.mobile.R
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.StatusTone

/** Compose colors derived from the shared DesignTokens (never hard-code colors in screens). */
object ShipaaColors {
    val primary = Color(DesignTokens.Color.primary)
    val primaryPressed = Color(DesignTokens.Color.primaryPressed)
    val onPrimary = Color(DesignTokens.Color.onPrimary)
    val grass = Color(DesignTokens.Color.grass)
    val background = Color(DesignTokens.Color.background)
    val surface = Color(DesignTokens.Color.surface)
    val surfaceMuted = Color(DesignTokens.Color.surfaceMuted)
    val ink = Color(DesignTokens.Color.ink)
    val muted = Color(DesignTokens.Color.muted)
    val line = Color(DesignTokens.Color.line)
    val lineStrong = Color(DesignTokens.Color.lineStrong)
    val lilac = Color(DesignTokens.Color.lilac)
    val lilacSoft = Color(DesignTokens.Color.lilacSoft)
    val sky = Color(DesignTokens.Color.sky)
    val skySoft = Color(DesignTokens.Color.skySoft)
    val success = Color(DesignTokens.Color.success)
    val successSoft = Color(DesignTokens.Color.successSoft)
    val warning = Color(DesignTokens.Color.warning)
    val warningSoft = Color(DesignTokens.Color.warningSoft)
    val danger = Color(DesignTokens.Color.danger)
    val dangerSoft = Color(DesignTokens.Color.dangerSoft)
    val player = Color(DesignTokens.Color.playerBackground)

    /** Foreground / background pair for a status tone. */
    fun tone(t: StatusTone): Pair<Color, Color> = when (t) {
        StatusTone.SUCCESS -> success to successSoft
        StatusTone.PROGRESS -> sky to skySoft
        StatusTone.NEUTRAL -> muted to surfaceMuted
        StatusTone.WARNING -> warning to warningSoft
        StatusTone.DANGER -> danger to dangerSoft
        StatusTone.LOCKED -> lilac to lilacSoft
    }
}

val Vazirmatn = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
)

private fun style(size: Int, weight: FontWeight = FontWeight.Normal) = TextStyle(
    fontFamily = Vazirmatn,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = (size * DesignTokens.Type.lineHeightRatio).sp,
)

private val typography = Typography(
    displaySmall = style(DesignTokens.Type.display, FontWeight.Bold),
    headlineSmall = style(DesignTokens.Type.heading, FontWeight.Bold),
    titleLarge = style(DesignTokens.Type.heading, FontWeight.Bold),
    titleMedium = style(DesignTokens.Type.title, FontWeight.Bold),
    titleSmall = style(DesignTokens.Type.body, FontWeight.Bold),
    bodyLarge = style(DesignTokens.Type.body),
    bodyMedium = style(DesignTokens.Type.body),
    bodySmall = style(DesignTokens.Type.small),
    labelLarge = style(DesignTokens.Type.small, FontWeight.Bold),
    labelMedium = style(DesignTokens.Type.caption, FontWeight.Medium),
    labelSmall = style(DesignTokens.Type.caption),
)

private val shapes = Shapes(
    extraSmall = RoundedCornerShape(DesignTokens.Radius.field.dp),
    small = RoundedCornerShape(DesignTokens.Radius.button.dp),
    medium = RoundedCornerShape(DesignTokens.Radius.card.dp),
    large = RoundedCornerShape(DesignTokens.Radius.panel.dp),
    extraLarge = RoundedCornerShape(DesignTokens.Radius.panel.dp),
)

private val colorScheme = lightColorScheme(
    primary = ShipaaColors.primary,
    onPrimary = ShipaaColors.onPrimary,
    primaryContainer = ShipaaColors.successSoft,
    onPrimaryContainer = ShipaaColors.primary,
    secondary = ShipaaColors.grass,
    onSecondary = ShipaaColors.onPrimary,
    tertiary = ShipaaColors.lilac,
    background = ShipaaColors.background,
    onBackground = ShipaaColors.ink,
    surface = ShipaaColors.surface,
    onSurface = ShipaaColors.ink,
    surfaceVariant = ShipaaColors.surfaceMuted,
    onSurfaceVariant = ShipaaColors.muted,
    surfaceContainer = ShipaaColors.surface,
    surfaceContainerHigh = ShipaaColors.surface,
    surfaceContainerHighest = ShipaaColors.surfaceMuted,
    outline = ShipaaColors.lineStrong,
    outlineVariant = ShipaaColors.line,
    error = ShipaaColors.danger,
    errorContainer = ShipaaColors.dangerSoft,
)

/**
 * The Shipaa theme: always light and RTL, like the website. Native screens must look like
 * part of shipaa.ir, not like a separate app.
 */
@Composable
fun ShipaaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colorScheme, typography = typography, shapes = shapes) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}

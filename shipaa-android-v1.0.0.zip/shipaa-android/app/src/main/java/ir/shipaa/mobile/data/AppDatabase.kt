package ir.shipaa.mobile.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Schema history is exported to app/schemas. When changing an entity, bump [version] and add
 * a Migration here — never use destructive migration: it would lose users' offline library.
 */
@Database(entities = [DownloadEntity::class, ProgressEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun downloads(): DownloadDao
    abstract fun progress(): ProgressDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "shipaa.db").build()
    }
}

package ir.shipaa.mobile.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.ui.theme.ShipaaColors

private val panelShape = RoundedCornerShape(DesignTokens.Radius.panel.dp)
private val cardShape = RoundedCornerShape(DesignTokens.Radius.card.dp)
private val buttonShape = RoundedCornerShape(DesignTokens.Radius.button.dp)
private val chipShape = RoundedCornerShape(DesignTokens.Radius.chip.dp)

/** White panel with the site's 1px border and 18dp corners. */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(panelShape)
            .background(ShipaaColors.surface)
            .border(1.dp, ShipaaColors.line, panelShape)
            .padding(DesignTokens.Space.md.dp)
    ) { content() }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(ShipaaColors.surface)
            .border(1.dp, ShipaaColors.line, cardShape)
            .padding(horizontal = DesignTokens.Space.sm.dp, vertical = DesignTokens.Space.sm.dp)
    ) { content() }
}

fun iconFor(state: DownloadState, error: DownloadError?): ImageVector = when (state) {
    DownloadState.COMPLETED -> Icons.Rounded.CheckCircle
    DownloadState.DOWNLOADING -> Icons.Rounded.CloudDownload
    DownloadState.QUEUED -> Icons.Rounded.HourglassTop
    DownloadState.WAITING_NETWORK -> if (error == DownloadError.SERVER) Icons.Rounded.Refresh else Icons.Rounded.WifiOff
    DownloadState.PAUSED -> Icons.Rounded.PauseCircle
    DownloadState.FAILED -> Icons.Rounded.Error
    DownloadState.NEEDS_VERIFICATION -> Icons.Rounded.VerifiedUser
    DownloadState.LOCKED -> Icons.Rounded.Lock
}

/** State chip: color + icon + text, so states never rely on color alone. */
@Composable
fun StatusChip(state: DownloadState, error: DownloadError?, percent: Int? = null) {
    val p = DownloadPresentation.of(state, error)
    val (fg, bg) = ShipaaColors.tone(p.tone)
    val label = if (state == DownloadState.DOWNLOADING && percent != null)
        "${p.label} · ${ir.shipaa.mobile.core.text.PersianFormat.percent(percent)}" else p.label
    Row(
        Modifier.clip(chipShape).background(bg).padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(iconFor(state, error), contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = fg, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ProgressLine(fraction: Float, color: Color = ShipaaColors.sky, modifier: Modifier = Modifier) {
    LinearProgressIndicator(
        progress = { fraction.coerceIn(0f, 1f) },
        modifier = modifier.fillMaxWidth().clip(CircleShape),
        color = color,
        trackColor = ShipaaColors.surfaceMuted,
        strokeCap = StrokeCap.Round,
        gapSize = 0.dp,
        drawStopIndicator = {},
    )
}

enum class ButtonKind { PRIMARY, SECONDARY, DANGER }

@Composable
fun ShipaaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.SECONDARY,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    val content: @Composable () -> Unit = {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    val padding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
    val minHeight = Modifier.heightIn(min = DesignTokens.Space.touch.dp)
    when (kind) {
        ButtonKind.PRIMARY -> Button(
            onClick = onClick, enabled = enabled, shape = buttonShape, contentPadding = padding,
            modifier = modifier.then(minHeight),
            colors = ButtonDefaults.buttonColors(containerColor = ShipaaColors.primary, contentColor = ShipaaColors.onPrimary),
        ) { content() }
        ButtonKind.SECONDARY, ButtonKind.DANGER -> {
            val fg = if (kind == ButtonKind.DANGER) ShipaaColors.danger else ShipaaColors.primary
            val border = if (kind == ButtonKind.DANGER) Color(0xFFEFCECD) else Color(0xFFCDDFD5)
            OutlinedButton(
                onClick = onClick, enabled = enabled, shape = buttonShape, contentPadding = padding,
                modifier = modifier.then(minHeight),
                border = BorderStroke(1.dp, border),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = ShipaaColors.surface, contentColor = fg),
            ) { content() }
        }
    }
}

/** Centered illustration + message used by empty, offline and error states. */
@Composable
fun MessageState(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    iconTint: Color = ShipaaColors.primary,
    actions: @Composable () -> Unit = {},
) {
    Column(
        modifier.padding(DesignTokens.Space.xl.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(ShipaaColors.successSoft),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(38.dp)) }
        Spacer(Modifier.padding(top = DesignTokens.Space.md.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = ShipaaColors.ink, textAlign = TextAlign.Center)
        Spacer(Modifier.padding(top = DesignTokens.Space.xs.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = ShipaaColors.muted, textAlign = TextAlign.Center)
        Spacer(Modifier.padding(top = DesignTokens.Space.lg.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) { actions() }
    }
}

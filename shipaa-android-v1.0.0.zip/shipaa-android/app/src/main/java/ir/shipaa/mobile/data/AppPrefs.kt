package ir.shipaa.mobile.data

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Small app settings and bookkeeping. Excluded from backup (data_extraction_rules.xml). */
class AppPrefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("shipaa_prefs", Context.MODE_PRIVATE)

    private val _wifiOnly = MutableStateFlow(sp.getBoolean(K_WIFI_ONLY, false))
    val wifiOnly: StateFlow<Boolean> = _wifiOnly.asStateFlow()

    fun setWifiOnly(value: Boolean) {
        sp.edit { putBoolean(K_WIFI_ONLY, value) }
        _wifiOnly.value = value
    }

    /** Highest wall-clock time ever observed; used to detect clock rollback (licence). */
    var lastSeenAt: Long
        get() = sp.getLong(K_LAST_SEEN, 0L)
        set(v) = sp.edit { putLong(K_LAST_SEEN, v) }

    /** Owner of the last signed-in account; survives cookie expiry while offline. */
    var lastOwnerKey: String?
        get() = sp.getString(K_LAST_OWNER, null)
        set(v) = sp.edit { if (v == null) remove(K_LAST_OWNER) else putString(K_LAST_OWNER, v) }

    var lastUsername: String?
        get() = sp.getString(K_LAST_USER, null)
        set(v) = sp.edit { if (v == null) remove(K_LAST_USER) else putString(K_LAST_USER, v) }

    var syncNonce: String?
        get() = sp.getString(K_SYNC_NONCE, null)
        set(v) = sp.edit { if (v == null) remove(K_SYNC_NONCE) else putString(K_SYNC_NONCE, v) }

    var syncNonceAt: Long
        get() = sp.getLong(K_SYNC_NONCE_AT, 0L)
        set(v) = sp.edit { putLong(K_SYNC_NONCE_AT, v) }

    /** The optional sync plugin is not installed; do not retry before this time. */
    var syncDisabledUntil: Long
        get() = sp.getLong(K_SYNC_OFF_UNTIL, 0L)
        set(v) = sp.edit { putLong(K_SYNC_OFF_UNTIL, v) }

    var lastUpdateCheckAt: Long
        get() = sp.getLong(K_UPDATE_AT, 0L)
        set(v) = sp.edit { putLong(K_UPDATE_AT, v) }

    var dismissedUpdateCode: Int
        get() = sp.getInt(K_UPDATE_DISMISSED, 0)
        set(v) = sp.edit { putInt(K_UPDATE_DISMISSED, v) }

    var notificationPermissionAsked: Boolean
        get() = sp.getBoolean(K_NOTIF_ASKED, false)
        set(v) = sp.edit { putBoolean(K_NOTIF_ASKED, v) }

    private companion object {
        const val K_WIFI_ONLY = "wifi_only"
        const val K_LAST_SEEN = "last_seen_at"
        const val K_LAST_OWNER = "last_owner"
        const val K_LAST_USER = "last_user"
        const val K_SYNC_NONCE = "sync_nonce"
        const val K_SYNC_NONCE_AT = "sync_nonce_at"
        const val K_SYNC_OFF_UNTIL = "sync_off_until"
        const val K_UPDATE_AT = "update_checked_at"
        const val K_UPDATE_DISMISSED = "update_dismissed"
        const val K_NOTIF_ASKED = "notif_asked"
    }
}

package ir.shipaa.mobile.player

import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.crypto.EncryptedVideoFile
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.license.AccessCheck
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.license.LicenseVerifier

sealed interface PlaybackPlan {
    data class Offline(val entity: DownloadEntity, val file: EncryptedVideoFile) : PlaybackPlan
    data class Online(val url: String) : PlaybackPlan
    data class Blocked(val title: String, val message: String) : PlaybackPlan
}

/** Chooses between the stored encrypted copy and online streaming, enforcing the offline licence. */
object PlaybackPlanner {
    suspend fun plan(video: VideoInfo, ownerKey: String?): PlaybackPlan {
        val repo = AppGraph.repo
        val online = AppGraph.connectivity.currentlyOnline()
        val stored = repo.get(VideoUrlPolicy.keyOf(video.src))

        if (stored != null && (stored.stateEnum == DownloadState.COMPLETED || stored.stateEnum == DownloadState.NEEDS_VERIFICATION)) {
            if (ownerKey != null && stored.ownerKey == ownerKey) {
                var current: DownloadEntity = stored
                val verdict = repo.licenseVerdict(stored)
                val needsCheck = verdict == LicensePolicy.Verdict.EXPIRED || verdict == LicensePolicy.Verdict.CLOCK_TAMPERED ||
                    stored.stateEnum == DownloadState.NEEDS_VERIFICATION
                if (needsCheck) {
                    if (!online) return Blocked(
                        "تمدید مجوز تماشای آفلاین",
                        "از آخرین اتصال شما مدتی گذشته است. یک بار به اینترنت وصل شوید تا تماشای آفلاین این جلسه تمدید شود.",
                    )
                    when (LicenseVerifier.verify(repo, current)) {
                        AccessCheck.GRANTED -> current = repo.get(stored.id) ?: return PlaybackPlan.Online(video.src)
                        AccessCheck.REVOKED -> return Blocked("دسترسی فعال نیست", "دسترسی شما به این جلسه در سایت شیپا فعال نیست.")
                        // Cannot decide (site or page changed): stream online; the site still controls access.
                        AccessCheck.LOGGED_OUT, AccessCheck.UNKNOWN -> return PlaybackPlan.Online(video.src)
                    }
                }
                return try {
                    PlaybackPlan.Offline(current, repo.encryptedFile(current))
                } catch (_: Exception) {
                    repo.markBroken(current.id, DownloadError.KEY_LOST)
                    if (online) PlaybackPlan.Online(video.src)
                    else Blocked("فایل ذخیره‌شده باز نشد", "این ویدئو باید دوباره دانلود شود.")
                }
            } else if (!online) {
                return Blocked("ذخیره متعلق به حساب دیگر", "این ویدئو برای حساب کاربری دیگری روی این گوشی ذخیره شده است.")
            }
        }
        if (stored?.stateEnum == DownloadState.LOCKED && stored.errorEnum == DownloadError.ACCESS_REVOKED && !online) {
            return Blocked("دسترسی فعال نیست", "دسترسی شما به این جلسه در سایت شیپا فعال نیست.")
        }
        return if (online) PlaybackPlan.Online(video.src)
        else Blocked("اینترنت در دسترس نیست", "این جلسه روی گوشی ذخیره نشده است. پس از اتصال به اینترنت دوباره تلاش کنید یا از کتابخانه، ویدئوهای ذخیره‌شده را ببینید.")
    }

    private fun Blocked(title: String, message: String) = PlaybackPlan.Blocked(title, message)
}

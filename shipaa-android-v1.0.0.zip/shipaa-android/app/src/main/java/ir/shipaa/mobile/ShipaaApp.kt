package ir.shipaa.mobile

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.data.AppDatabase
import ir.shipaa.mobile.data.AppPrefs
import ir.shipaa.mobile.data.DownloadRepository
import ir.shipaa.mobile.download.DownloadScheduler
import ir.shipaa.mobile.license.LicenseWorker
import ir.shipaa.mobile.net.Connectivity
import ir.shipaa.mobile.net.Http
import ir.shipaa.mobile.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.TimeUnit

class ShipaaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Http.init(this)
        AppGraph.init(this)
        createChannels()
        AppGraph.scope.launch {
            AppGraph.scheduler.reconcile()
            LicenseWorker.schedulePeriodic(this@ShipaaApp)
        }
        // When connectivity returns while the app is alive, resume waiting downloads at once
        // instead of waiting for the worker's back-off.
        AppGraph.scope.launch {
            AppGraph.connectivity.online.drop(1).filter { it }.collect { AppGraph.scheduler.resumeWaiting() }
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DOWNLOADS, getString(R.string.channel_downloads), NotificationManager.IMPORTANCE_LOW)
                .apply { description = getString(R.string.channel_downloads_desc); setShowBadge(false) }
        )
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "downloads"
    }
}

/** Minimal service locator; everything here is process-wide and thread-safe. */
object AppGraph {
    lateinit var prefs: AppPrefs
        private set
    lateinit var db: AppDatabase
        private set
    lateinit var repo: DownloadRepository
        private set
    lateinit var session: Session
        private set
    lateinit var connectivity: Connectivity
        private set
    lateinit var scheduler: DownloadScheduler
        private set
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Synchronized
    fun init(context: Context) {
        if (::repo.isInitialized) return
        val app = context.applicationContext
        prefs = AppPrefs(app)
        db = AppDatabase.build(app)
        val videos = File(app.filesDir, "videos").apply { mkdirs() }
        repo = DownloadRepository(db, videos, prefs, LicensePolicy(validityMs = TimeUnit.DAYS.toMillis(BuildConfig.LICENSE_DAYS.toLong())))
        session = Session(prefs)
        connectivity = Connectivity(app)
        scheduler = DownloadScheduler(app, repo, prefs)
    }

    /** Workers may run in a fresh process before Application.onCreate finished elsewhere. */
    fun ensure(context: Context) { if (!::repo.isInitialized) { Http.init(context); init(context) } }
}

package ir.shipaa.mobile.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.download.DownloadState

/** One stored (or downloading) lesson video. [id] is VideoUrlPolicy.keyOf(videoUrl). */
@Entity(tableName = "downloads", indices = [Index("ownerKey"), Index("state")])
data class DownloadEntity(
    @PrimaryKey val id: String,
    val videoUrl: String,
    val pageUrl: String,
    val lessonId: Long?,
    val title: String,
    val course: String,
    val poster: String?,
    val ownerKey: String,
    val state: String,
    val error: String?,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val etag: String?,
    val lastModified: String?,
    val fileName: String,
    /** Per-file AES key wrapped by the Android Keystore master key (base64). */
    val wrappedKey: String,
    /** CTR nonce (base64, 8 bytes). Not secret. */
    val nonce: String,
    val createdAt: Long,
    val updatedAt: Long,
    /** Last time the site confirmed the user can watch this lesson. */
    val verifiedAt: Long,
) {
    val stateEnum: DownloadState get() = DownloadState.parse(state)
    val errorEnum: DownloadError? get() = DownloadError.parse(error)
    val percent: Int get() = DownloadPresentation.percent(downloadedBytes, totalBytes, stateEnum == DownloadState.COMPLETED)
}

/** Watch position per account and video. */
@Entity(tableName = "progress", primaryKeys = ["ownerKey", "videoKey"])
data class ProgressEntity(
    val ownerKey: String,
    val videoKey: String,
    val videoUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
    /** Changed locally and not yet sent to the optional sync plugin. */
    val dirty: Boolean,
)

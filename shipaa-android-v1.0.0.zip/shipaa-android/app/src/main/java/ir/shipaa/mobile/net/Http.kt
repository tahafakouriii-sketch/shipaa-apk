package ir.shipaa.mobile.net

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebSettings
import ir.shipaa.mobile.BuildConfig
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import java.util.concurrent.TimeUnit

/**
 * One OkHttp client for downloads, online playback, licence checks and update checks.
 * It shares the WebView's cookies for Shipaa hosts only, so the site's own login decides access.
 */
object Http {
    private val shipaaHosts = setOf("shipaa.ir", "www.shipaa.ir", "dl.shipaa.ir")

    @Volatile private var client: OkHttpClient? = null
    @Volatile var userAgent: String = "ShipaaApp/${BuildConfig.VERSION_NAME}"
        private set

    fun init(context: Context) {
        userAgent = try {
            WebSettings.getDefaultUserAgent(context) + " ShipaaApp/" + BuildConfig.VERSION_NAME
        } catch (_: Exception) {
            "Mozilla/5.0 (Linux; Android) ShipaaApp/" + BuildConfig.VERSION_NAME
        }
    }

    fun client(): OkHttpClient = client ?: synchronized(this) {
        client ?: OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(false) // never downgrade from https
            .addInterceptor(SessionInterceptor)
            .build()
            .also { client = it }
    }

    private object SessionInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            val req = chain.request()
            val b = req.newBuilder().header("User-Agent", userAgent)
            if (req.url.isHttps && req.url.host in shipaaHosts && req.header("Cookie") == null) {
                val cookies = try { CookieManager.getInstance().getCookie(req.url.toString()) } catch (_: Exception) { null }
                if (!cookies.isNullOrBlank()) b.header("Cookie", cookies)
            }
            return chain.proceed(b.build())
        }
    }

    fun siteCookies(): String? = try {
        CookieManager.getInstance().getCookie(BuildConfig.SITE_ORIGIN)
    } catch (_: Exception) { null }
}

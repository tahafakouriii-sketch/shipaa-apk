package ir.shipaa.mobile.web

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.BuildConfig
import ir.shipaa.mobile.core.bridge.BridgeMessage
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.nav.NavigationPolicy
import ir.shipaa.mobile.core.update.UpdateDecision
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.library.LibraryActivity
import ir.shipaa.mobile.net.Http
import ir.shipaa.mobile.net.Session
import ir.shipaa.mobile.player.PlayerActivity
import ir.shipaa.mobile.sync.ProgressSyncWorker
import ir.shipaa.mobile.ui.theme.ShipaaTheme
import ir.shipaa.mobile.update.UpdateChecker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * The website (shipaa.ir) inside the app, plus native layers for things the site cannot do:
 * offline/server error screens, the active-download pill and update notices.
 * There is deliberately NO native tab bar: the site's own menus are the navigation.
 */
class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var errorLayer: ComposeView
    private lateinit var bridge: ShipaaBridge

    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingDownload: VideoInfo? = null
    private var loadFailed = false

    internal val errorKind = MutableStateFlow(ErrorKind.NONE)
    internal val update = MutableStateFlow<UpdateDecision>(UpdateDecision.UpToDate)
    /** Lesson videos found on the current page (normalized URLs). */
    private val pageVideos = MutableStateFlow<List<String>>(emptyList())

    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        pendingDownload?.let { startDownload(it) }
        pendingDownload = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.WHITE, Color.WHITE),
            navigationBarStyle = SystemBarStyle.light(Color.WHITE, Color.WHITE),
        )
        super.onCreate(savedInstanceState)
        AppGraph.ensure(this)
        buildViews()
        configureWebView()
        observeState()
        onBackPressedDispatcher.addCallback(this, backCallback)

        val restored = savedInstanceState?.let { web.restoreState(it) } != null
        if (!restored) web.loadUrl(initialUrl(intent))
        if (savedInstanceState == null && intent?.action == ACTION_OPEN_LIBRARY) openLibrary()
        checkForUpdate()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_OPEN_LIBRARY) { openLibrary(); return }
        val target = urlFromIntent(intent) ?: return
        errorKind.value = ErrorKind.NONE
        web.loadUrl(target)
    }

    // ---------------------------------------------------------------- views

    private fun buildViews() {
        root = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.WHITE)
        }
        webContainer = FrameLayout(this)
        web = WebView(this)
        webContainer.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = false
            progressTintList = android.content.res.ColorStateList.valueOf(DesignTokens.Color.grass.toInt())
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
            visibility = View.GONE
        }
        webContainer.addView(progress, FrameLayout.LayoutParams(MATCH, dp(3), Gravity.TOP))
        root.addView(webContainer, FrameLayout.LayoutParams(MATCH, MATCH))

        // Error screens cover the page; GONE when there is no error so touches reach the site.
        errorLayer = composeLayer { ShipaaTheme { ErrorLayer(this@MainActivity) } }.apply { visibility = View.GONE }
        root.addView(errorLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        // Small, wrap-content layers: update banner (top) and active-download pill (bottom).
        root.addView(composeLayer { ShipaaTheme { UpdateBanner(this@MainActivity) } },
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        root.addView(composeLayer { ShipaaTheme { DownloadPill(this@MainActivity) } },
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        ViewCompat.setOnApplyWindowInsetsListener(webContainer) { v, insets ->
            if (fullscreenView != null) {
                v.setPadding(0, 0, 0, 0)
            } else {
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            }
            insets
        }
        setContentView(root)
    }

    private fun composeLayer(content: @androidx.compose.runtime.Composable () -> Unit) = ComposeView(this).apply {
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        setContent(content)
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        with(web.settings) {
            javaScriptEnabled = true // required by WordPress / Studiare
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100 // the site's own sizes, not the system font scale twice
            userAgentString = "$userAgentString ShipaaApp/${BuildConfig.VERSION_NAME}"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.isVerticalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER

        bridge = ShipaaBridge(web, ::onBridgeMessage).also { it.install(this) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val url = request.url.toString()
                if (Session.isLogoutUrl(url)) AppGraph.session.markLoggedOut()
                val decision = NavigationPolicy.decide(
                    url, VideoUrlPolicy::isAllowed,
                    userGesture = request.hasGesture() && !request.isRedirect,
                    fromSitePage = NavigationPolicy.isSitePage(view.url),
                )
                return when (decision) {
                    NavigationPolicy.Decision.InApp ->
                        if (url.startsWith("http://")) { view.loadUrl("https://" + url.removePrefix("http://")); true } else false
                    NavigationPolicy.Decision.OpenLibrary -> { openLibrary(); true }
                    is NavigationPolicy.Decision.PlayNative -> { playFromLink(decision.videoUrl); true }
                    is NavigationPolicy.Decision.External -> { openExternal(Uri.parse(decision.url)); true }
                    NavigationPolicy.Decision.Block -> true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                bridge.currentUrl = url
                loadFailed = false
                pageVideos.value = emptyList()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                bridge.currentUrl = url
            }

            override fun onPageFinished(view: WebView, url: String?) {
                bridge.currentUrl = url
                bridge.onPageFinished(url)
                CookieManager.getInstance().flush()
                AppGraph.session.refresh()
                if (!loadFailed) errorKind.value = ErrorKind.NONE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                loadFailed = true
                errorKind.value = ErrorKind.OFFLINE
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                if (request.isForMainFrame && response.statusCode >= 500) {
                    loadFailed = true
                    errorKind.value = ErrorKind.SERVER
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.isVisible = newProgress < 100 && fullscreenView == null
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return }
                fullscreenView = view
                fullscreenCallback = callback
                root.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                systemBars(hidden = true)
            }

            override fun onHideCustomView() = exitFullscreen()

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams,
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (_: ActivityNotFoundException) {
                    filePathCallback = null
                    toast("برنامه‌ای برای انتخاب فایل پیدا نشد")
                    false
                }
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val video = VideoUrlPolicy.normalize(url)
            if (video != null) {
                // Lesson videos are never saved as plain files: use the encrypted library.
                requestDownload(VideoInfo(video, VideoUrlPolicy.fallbackTitle(video), "", null, web.url ?: "", null))
            } else {
                downloadResource(url, userAgent, contentDisposition, mimeType)
            }
        }
    }

    private fun exitFullscreen() {
        val v = fullscreenView ?: return
        fullscreenView = null
        root.removeView(v)
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        systemBars(hidden = false)
        ViewCompat.requestApplyInsets(webContainer)
    }

    private fun systemBars(hidden: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hidden) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    /** Supplementary files (PDF, slides): system download manager with the user's session. */
    private fun downloadResource(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https") return
        if (Build.VERSION.SDK_INT < 29) { openExternal(uri); return }
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val req = DownloadManager.Request(uri)
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent ?: Http.userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Shipaa/$name")
                .setTitle(name)
            if (NavigationPolicy.isSitePage(url) || uri.host == "dl.shipaa.ir") {
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            }
            getSystemService(DownloadManager::class.java).enqueue(req)
            toast("دانلود «$name» شروع شد")
        } catch (_: Exception) {
            openExternal(uri)
        }
    }

    // ---------------------------------------------------------------- bridge

    private fun onBridgeMessage(msg: BridgeMessage) {
        when (msg) {
            is BridgeMessage.Hello -> Unit
            is BridgeMessage.Videos -> {
                pageVideos.value = msg.items.map { it.src }
                val owner = AppGraph.session.refresh()?.ownerKey
                if (owner != null && msg.items.isNotEmpty()) {
                    lifecycleScope.launch { AppGraph.repo.markSeenOnPage(msg.items.map { it.src }, owner) }
                }
            }
            is BridgeMessage.Play -> startActivity(PlayerActivity.createIntent(this, msg.video))
            is BridgeMessage.Download -> requestDownload(msg.video)
            is BridgeMessage.Pause -> lifecycleScope.launch { AppGraph.scheduler.pause(VideoUrlPolicy.keyOf(msg.src)) }
            is BridgeMessage.Resume -> lifecycleScope.launch { AppGraph.scheduler.resume(VideoUrlPolicy.keyOf(msg.src)) }
            BridgeMessage.OpenLibrary -> openLibrary()
            is BridgeMessage.SyncNonce -> {
                AppGraph.prefs.syncNonce = msg.nonce
                AppGraph.prefs.syncNonceAt = System.currentTimeMillis()
                ProgressSyncWorker.request(this)
            }
        }
    }

    private fun requestDownload(video: VideoInfo) {
        if (Build.VERSION.SDK_INT >= 33 && !AppGraph.prefs.notificationPermissionAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            AppGraph.prefs.notificationPermissionAsked = true
            pendingDownload = video
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startDownload(video)
    }

    private fun startDownload(video: VideoInfo) {
        val owner = AppGraph.session.refresh()?.takeIf { it.fromLiveCookie }?.ownerKey
        if (owner == null) {
            toast("برای ذخیره جلسه، ابتدا وارد حساب کاربری شوید")
            return
        }
        lifecycleScope.launch {
            AppGraph.scheduler.enqueue(video, owner)
            toast("به صف ذخیره آفلاین اضافه شد")
        }
    }

    private fun playFromLink(url: String) {
        val src = VideoUrlPolicy.normalize(url) ?: return
        startActivity(PlayerActivity.createIntent(this, VideoInfo(src, VideoUrlPolicy.fallbackTitle(src), "", null, web.url ?: "", null)))
    }

    internal fun openLibrary() = startActivity(Intent(this, LibraryActivity::class.java))

    internal fun retry() {
        errorKind.value = ErrorKind.NONE
        if (web.url.isNullOrBlank() || web.url == "about:blank") web.loadUrl(BuildConfig.START_URL) else web.reload()
    }

    internal fun goHome() {
        errorKind.value = ErrorKind.NONE
        web.loadUrl(BuildConfig.START_URL)
    }

    internal fun dismissUpdate(code: Int) {
        AppGraph.prefs.dismissedUpdateCode = code
        update.value = UpdateDecision.UpToDate
    }

    internal fun openUpdate(url: String) = openExternal(Uri.parse(url))

    private fun observeState() {
        // Keep the injected bar under each video in sync with the download database.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(pageVideos, AppGraph.repo.observeAll()) { srcs, all -> srcs to all.associateBy { it.id } }
                    .collect { (srcs, map) -> bridge.pushStates(srcs, map) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                errorKind.collect { errorLayer.isVisible = it != ErrorKind.NONE || update.value is UpdateDecision.Required }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                update.collect { errorLayer.isVisible = errorKind.value != ErrorKind.NONE || it is UpdateDecision.Required }
            }
        }
        // Back online while an offline screen is shown: reload automatically.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                AppGraph.connectivity.online.collect { online ->
                    if (online && errorKind.value == ErrorKind.OFFLINE) retry()
                }
            }
        }
    }

    private fun checkForUpdate() {
        lifecycleScope.launch {
            val d = UpdateChecker.check(AppGraph.prefs)
            if (d !is UpdateDecision.UpToDate) update.value = d
        }
    }

    // ---------------------------------------------------------------- back

    private val backCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            when {
                fullscreenView != null -> exitFullscreen()
                errorKind.value != ErrorKind.NONE && web.canGoBack() -> { errorKind.value = ErrorKind.NONE; web.goBack() }
                else -> bridge.handleBack { handled ->
                    if (handled) return@handleBack
                    if (web.canGoBack()) web.goBack() else finishAfterDefaultBack()
                }
            }
        }
    }

    private fun finishAfterDefaultBack() {
        backCallback.isEnabled = false
        onBackPressedDispatcher.onBackPressed()
        backCallback.isEnabled = true
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        web.onResume()
        AppGraph.session.refresh()
    }

    override fun onPause() {
        web.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers

    private fun initialUrl(intent: Intent?): String = urlFromIntent(intent) ?: BuildConfig.START_URL

    private fun urlFromIntent(intent: Intent?): String? {
        val candidate = intent?.getStringExtra(EXTRA_URL) ?: intent?.data?.toString()
        return candidate?.takeIf { NavigationPolicy.isSitePage(it) && it.startsWith("https://") }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (_: ActivityNotFoundException) {
            toast("برنامه‌ای برای باز کردن این پیوند پیدا نشد")
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    enum class ErrorKind { NONE, OFFLINE, SERVER }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        const val EXTRA_URL = "url"
        /** Launcher shortcut "ذخیره‌های من". */
        const val ACTION_OPEN_LIBRARY = "ir.shipaa.mobile.action.OPEN_LIBRARY"

        fun open(context: Context, url: String) {
            context.startActivity(
                Intent(context, MainActivity::class.java).putExtra(EXTRA_URL, url)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
    }
}

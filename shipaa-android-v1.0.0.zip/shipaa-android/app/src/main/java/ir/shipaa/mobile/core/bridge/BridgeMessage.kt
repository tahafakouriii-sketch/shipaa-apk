package ir.shipaa.mobile.core.bridge

import ir.shipaa.mobile.core.video.VideoUrlPolicy

/** Metadata about a lesson video, as reported by bridge.js from a shipaa.ir page. */
data class VideoInfo(
    val src: String,
    val title: String,
    val course: String,
    val lessonId: Long?,
    val pageUrl: String,
    val poster: String?,
)

/** Validated messages from the page. Unknown or malformed input is rejected, never trusted. */
sealed interface BridgeMessage {
    data class Hello(val bridgeVersion: Int, val fontFamily: String) : BridgeMessage
    data class Videos(val items: List<VideoInfo>) : BridgeMessage
    data class Play(val video: VideoInfo) : BridgeMessage
    data class Download(val video: VideoInfo) : BridgeMessage
    data class Pause(val src: String) : BridgeMessage
    data class Resume(val src: String) : BridgeMessage
    data object OpenLibrary : BridgeMessage
    data class SyncNonce(val nonce: String) : BridgeMessage

    companion object {
        const val MAX_ITEMS = 50
        private const val MAX_TEXT = 300

        /**
         * Builds a message from already-decoded JSON fields. Kept free of any JSON library so it
         * can be unit-tested; [BridgeJson] in the Android layer does the decoding.
         */
        fun from(type: String?, fields: Map<String, Any?>, pageUrl: String?): BridgeMessage? {
            return when (type) {
                "hello" -> Hello((fields["bridgeVersion"] as? Number)?.toInt() ?: 0, text(fields["fontFamily"]) ?: "")
                "videos" -> {
                    val raw = fields["items"] as? List<*> ?: return null
                    Videos(raw.take(MAX_ITEMS).mapNotNull { (it as? Map<*, *>)?.let { m -> video(m, pageUrl) } }
                        .distinctBy { it.src })
                }
                "play" -> video(fields, pageUrl)?.let(::Play)
                "download" -> video(fields, pageUrl)?.let(::Download)
                "pause" -> VideoUrlPolicy.normalize(fields["src"] as? String)?.let(::Pause)
                "resume" -> VideoUrlPolicy.normalize(fields["src"] as? String)?.let(::Resume)
                "openLibrary" -> OpenLibrary
                "syncNonce" -> (fields["nonce"] as? String)?.takeIf { it.matches(Regex("^[a-zA-Z0-9]{6,32}$")) }?.let(::SyncNonce)
                else -> null
            }
        }

        private fun video(m: Map<*, *>, pageUrl: String?): VideoInfo? {
            val src = VideoUrlPolicy.normalize(m["src"] as? String) ?: return null
            val page = (m["pageUrl"] as? String)?.takeIf { isShipaaPage(it) } ?: pageUrl?.takeIf { isShipaaPage(it) } ?: ""
            val poster = (m["poster"] as? String)?.takeIf { it.startsWith("https://") && it.length < 2048 }
            val lessonId = when (val v = m["lessonId"]) {
                is Number -> v.toLong()
                is String -> v.toLongOrNull()
                else -> null
            }?.takeIf { it > 0 }
            return VideoInfo(
                src = src,
                title = text(m["title"]) ?: VideoUrlPolicy.fallbackTitle(src),
                course = text(m["course"]) ?: "",
                lessonId = lessonId,
                pageUrl = page.substringBefore('#'),
                poster = poster,
            )
        }

        private fun text(v: Any?): String? =
            (v as? String)?.replace(Regex("\\s+"), " ")?.trim()?.take(MAX_TEXT)?.takeIf { it.isNotEmpty() }

        private fun isShipaaPage(url: String): Boolean =
            url.length < 2048 && (url.startsWith("https://shipaa.ir/") || url.startsWith("https://www.shipaa.ir/"))
    }
}

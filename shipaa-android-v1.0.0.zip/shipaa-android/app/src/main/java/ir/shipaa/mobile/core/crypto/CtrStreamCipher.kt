package ir.shipaa.mobile.core.crypto

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-CTR keystream that can start at any byte offset. Used to encrypt downloads as
 * they are written (append, resume) and to decrypt during playback with free seeking.
 *
 * Counter block = 8-byte random nonce || 8-byte big-endian block counter.
 * Encryption and decryption are the same operation (XOR with the keystream).
 */
class CtrStreamCipher(key: ByteArray, private val nonce: ByteArray) {
    private val keySpec = SecretKeySpec(key.copyOf(), "AES")

    init {
        require(key.size == KEY_BYTES) { "AES-256 key must be $KEY_BYTES bytes" }
        require(nonce.size == NONCE_BYTES) { "nonce must be $NONCE_BYTES bytes" }
    }

    /** A cipher positioned at [position] (bytes from the start of the plaintext). */
    fun at(position: Long): Session {
        require(position >= 0) { "position must be >= 0" }
        val block = position / BLOCK
        val skip = (position % BLOCK).toInt()
        val iv = ByteArray(BLOCK)
        System.arraycopy(nonce, 0, iv, 0, NONCE_BYTES)
        for (i in 0 until 8) iv[15 - i] = (block ushr (8 * i)).toByte()
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, IvParameterSpec(iv))
        if (skip > 0) cipher.update(ByteArray(skip))
        return Session(cipher)
    }

    class Session internal constructor(private val cipher: Cipher) {
        /** Transforms [length] bytes of [buffer] starting at [offset] in place. */
        fun transform(buffer: ByteArray, offset: Int, length: Int) {
            if (length <= 0) return
            val produced = cipher.update(buffer, offset, length, buffer, offset)
            check(produced == length) { "CTR produced $produced of $length bytes" }
        }
    }

    companion object {
        const val KEY_BYTES = 32
        const val NONCE_BYTES = 8
        private const val BLOCK = 16

        fun newKey(random: SecureRandom = SecureRandom()): ByteArray = ByteArray(KEY_BYTES).also(random::nextBytes)
        fun newNonce(random: SecureRandom = SecureRandom()): ByteArray = ByteArray(NONCE_BYTES).also(random::nextBytes)
    }
}

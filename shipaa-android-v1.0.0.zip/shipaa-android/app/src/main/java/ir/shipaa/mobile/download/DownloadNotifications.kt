package ir.shipaa.mobile.download

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ForegroundInfo
import ir.shipaa.mobile.R
import ir.shipaa.mobile.ShipaaApp
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.library.LibraryActivity

class DownloadNotifications(private val context: Context) {

    private fun libraryIntent(): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, LibraryActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun pauseIntent(id: String): PendingIntent = PendingIntent.getBroadcast(
        context, id.hashCode(),
        Intent(context, DownloadActionReceiver::class.java).setAction(DownloadActionReceiver.ACTION_PAUSE)
            .putExtra(DownloadActionReceiver.EXTRA_ID, id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun base(): NotificationCompat.Builder =
        NotificationCompat.Builder(context, ShipaaApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(DesignTokens.Color.primary.toInt())
            .setContentIntent(libraryIntent())
            .setOnlyAlertOnce(true)

    fun foregroundInfo(e: DownloadEntity, percent: Int, indeterminate: Boolean): ForegroundInfo {
        val text = if (indeterminate) "در حال آماده‌سازی دانلود…"
        else "${PersianFormat.percent(percent)} · ${PersianFormat.bytes(e.downloadedBytes)} از ${PersianFormat.bytes(e.totalBytes)}"
        val n = base()
            .setContentTitle(e.title)
            .setContentText(text)
            .setSubText("ذخیره برای تماشای آفلاین")
            .setProgress(100, percent, indeterminate)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(0, "توقف", pauseIntent(e.id))
            .build()
        return foreground(progressId(e.id), n)
    }

    fun genericForegroundInfo(): ForegroundInfo =
        foreground(GENERIC_ID, base().setContentTitle("دانلود ویدئوهای شیپا").setProgress(0, 0, true).setOngoing(true).build())

    private fun foreground(id: Int, n: Notification): ForegroundInfo =
        if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(id, n)

    fun completed(e: DownloadEntity) = post(
        resultId(e.id),
        base().setContentTitle("آماده تماشای آفلاین").setContentText(e.title).setAutoCancel(true).build(),
    )

    fun failed(e: DownloadEntity, error: DownloadError) = post(
        resultId(e.id),
        base().setContentTitle("دانلود ناقص ماند").setContentText("${e.title} — ${DownloadPresentation.errorLabel(error)}")
            .setAutoCancel(true).build(),
    )

    @SuppressLint("MissingPermission") // checked by canPost()
    private fun post(id: Int, n: Notification) {
        if (!canPost()) return
        try { NotificationManagerCompat.from(context).notify(id, n) } catch (_: SecurityException) { }
    }

    private fun canPost(): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun progressId(id: String) = 10_000 + (id.hashCode() and 0xFFFF)
    private fun resultId(id: String) = 80_000 + (id.hashCode() and 0xFFFF)

    private companion object { const val GENERIC_ID = 9_999 }
}

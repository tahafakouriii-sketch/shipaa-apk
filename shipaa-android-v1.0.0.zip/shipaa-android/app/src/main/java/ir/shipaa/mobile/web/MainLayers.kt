package ir.shipaa.mobile.web

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadPresentation
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.core.update.UpdateDecision
import ir.shipaa.mobile.ui.components.ButtonKind
import ir.shipaa.mobile.ui.components.MessageState
import ir.shipaa.mobile.ui.components.ShipaaButton
import ir.shipaa.mobile.ui.theme.ShipaaColors

/** Full-screen native states shown instead of a broken page. */
@Composable
internal fun ErrorLayer(activity: MainActivity) {
    val kind by activity.errorKind.collectAsState()
    val update by activity.update.collectAsState()
    val account by AppGraph.session.account.collectAsState()
    val downloads by remember { AppGraph.repo.observeAll() }.collectAsState(initial = emptyList())
    val saved = downloads.count { it.ownerKey == account?.ownerKey && it.stateEnum == DownloadState.COMPLETED }
    val libraryLabel = if (saved > 0) "ویدئوهای ذخیره‌شده (${PersianFormat.number(saved)})" else "ویدئوهای ذخیره‌شده"

    Box(
        Modifier.fillMaxSize().background(ShipaaColors.background).systemBarsPadding().verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.Center,
    ) {
        val required = update as? UpdateDecision.Required
        when {
            required != null -> MessageState(
                icon = Icons.Rounded.SystemUpdate,
                title = "به‌روزرسانی اپ شیپا لازم است",
                body = "نسخه ${PersianFormat.digits(required.manifest.versionName)} منتشر شده و نسخه فعلی دیگر پشتیبانی نمی‌شود. " +
                    "ویدئوهای ذخیره‌شده همچنان در دسترس‌اند.",
            ) {
                ShipaaButton("دریافت نسخه جدید", { activity.openUpdate(required.manifest.downloadUrl) }, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.SystemUpdate)
                ShipaaButton(libraryLabel, activity::openLibrary, icon = Icons.Rounded.VideoLibrary)
            }
            kind == MainActivity.ErrorKind.SERVER -> MessageState(
                icon = Icons.Rounded.Warning,
                iconTint = ShipaaColors.warning,
                title = "سایت شیپا موقتاً پاسخ نمی‌دهد",
                body = "مشکل از سمت سرور است و اطلاعات شما محفوظ است. چند لحظه دیگر دوباره تلاش کنید.",
            ) {
                ShipaaButton("تلاش دوباره", activity::retry, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Refresh)
                ShipaaButton("خانه یادگیری", activity::goHome, icon = Icons.Rounded.Home)
                ShipaaButton(libraryLabel, activity::openLibrary, icon = Icons.Rounded.VideoLibrary)
            }
            else -> MessageState(
                icon = Icons.Rounded.CloudOff,
                title = "اتصال به اینترنت برقرار نیست",
                body = if (saved > 0) "اینترنت را بررسی کنید. تا آن موقع می‌توانید ویدئوهایی را که ذخیره کرده‌اید بدون اینترنت تماشا کنید."
                else "اینترنت را بررسی کنید و دوباره تلاش کنید. با «ذخیره برای آفلاین» در صفحه هر جلسه، آن را بدون اینترنت هم می‌بینید.",
            ) {
                if (saved > 0) {
                    ShipaaButton(libraryLabel, activity::openLibrary, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.VideoLibrary)
                    ShipaaButton("تلاش دوباره", activity::retry, icon = Icons.Rounded.Refresh)
                } else {
                    ShipaaButton("تلاش دوباره", activity::retry, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Refresh)
                    ShipaaButton(libraryLabel, activity::openLibrary, icon = Icons.Rounded.VideoLibrary)
                }
            }
        }
    }
}

/** Dismissible notice for an optional update. */
@Composable
internal fun UpdateBanner(activity: MainActivity) {
    val update by activity.update.collectAsState()
    val optional = update as? UpdateDecision.Optional
    AnimatedVisibility(
        visible = optional != null,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
    ) {
        val m = optional?.manifest ?: return@AnimatedVisibility
        Row(
            Modifier
                .statusBarsPadding()
                .padding(DesignTokens.Space.sm.dp)
                .fillMaxWidth()
                .shadow(8.dp, RoundedCornerShape(DesignTokens.Radius.card.dp))
                .clip(RoundedCornerShape(DesignTokens.Radius.card.dp))
                .background(ShipaaColors.surface)
                .border(1.dp, ShipaaColors.line, RoundedCornerShape(DesignTokens.Radius.card.dp))
                .padding(DesignTokens.Space.sm.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(DesignTokens.Space.xs.dp),
        ) {
            Icon(Icons.Rounded.SystemUpdate, contentDescription = null, tint = ShipaaColors.primary)
            Column(Modifier.weight(1f)) {
                Text("نسخه جدید شیپا آماده است (${PersianFormat.digits(m.versionName)})", style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink)
                if (m.notes.isNotBlank()) {
                    Text(m.notes, style = MaterialTheme.typography.bodySmall, color = ShipaaColors.muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            ShipaaButton("دریافت", { activity.openUpdate(m.downloadUrl) }, kind = ButtonKind.PRIMARY)
            ShipaaButton("بعداً", { activity.dismissUpdate(m.latestVersionCode) })
        }
    }
}

/** Small floating indicator while downloads run; opens the library. Hidden when idle. */
@Composable
internal fun DownloadPill(activity: MainActivity) {
    val downloads by remember { AppGraph.repo.observeAll() }.collectAsState(initial = emptyList())
    val active = downloads.filter { it.stateEnum == DownloadState.DOWNLOADING || it.stateEnum == DownloadState.QUEUED || it.stateEnum == DownloadState.WAITING_NETWORK }
    val error by activity.errorKind.collectAsState()
    AnimatedVisibility(
        visible = active.isNotEmpty() && error == MainActivity.ErrorKind.NONE,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
    ) {
        val done = active.sumOf { it.downloadedBytes }
        val total = active.sumOf { it.totalBytes }
        val pct = DownloadPresentation.percent(done, total, false)
        val text = if (active.size == 1) "در حال ذخیره · ${PersianFormat.percent(pct)}"
        else "ذخیره ${PersianFormat.number(active.size)} ویدئو · ${PersianFormat.percent(pct)}"
        Row(
            Modifier
                .navigationBarsPadding()
                .padding(bottom = 84.dp)
                .shadow(10.dp, RoundedCornerShape(50))
                .clip(RoundedCornerShape(50))
                .background(ShipaaColors.surface)
                .border(1.dp, ShipaaColors.line, RoundedCornerShape(50))
                .clickable(role = Role.Button, onClickLabel = "باز کردن ذخیره‌ها") { activity.openLibrary() }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.CloudDownload, contentDescription = null, tint = ShipaaColors.sky, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, style = MaterialTheme.typography.labelLarge, color = ShipaaColors.ink)
        }
    }
}

package ir.shipaa.mobile.library

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.BuildConfig
import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.design.DesignTokens
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.license.AccessCheck
import ir.shipaa.mobile.core.text.PersianFormat
import ir.shipaa.mobile.core.update.UpdateDecision
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.license.LicenseVerifier
import ir.shipaa.mobile.player.PlayerActivity
import ir.shipaa.mobile.ui.components.ButtonKind
import ir.shipaa.mobile.ui.components.CardBox
import ir.shipaa.mobile.ui.components.MessageState
import ir.shipaa.mobile.ui.components.Panel
import ir.shipaa.mobile.ui.components.ProgressLine
import ir.shipaa.mobile.ui.components.ShipaaButton
import ir.shipaa.mobile.ui.components.StatusChip
import ir.shipaa.mobile.ui.theme.ShipaaColors
import ir.shipaa.mobile.ui.theme.ShipaaTheme
import ir.shipaa.mobile.update.UpdateChecker
import ir.shipaa.mobile.web.MainActivity
import kotlinx.coroutines.launch

/** The offline library: every saved lesson of the signed-in account, usable without internet. */
class LibraryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        AppGraph.ensure(this)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        AppGraph.session.refresh()
        setContent { ShipaaTheme { LibraryScreen(this) } }
    }

    override fun onResume() {
        super.onResume()
        AppGraph.session.refresh()
    }

    internal fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    internal fun play(e: DownloadEntity) = startActivity(
        PlayerActivity.createIntent(this, VideoInfo(e.videoUrl, e.title, e.course, e.lessonId, e.pageUrl, e.poster))
    )

    internal fun openLesson(e: DownloadEntity) {
        if (e.pageUrl.isNotBlank()) MainActivity.open(this, e.pageUrl)
    }

    internal fun openSite() = MainActivity.open(this, BuildConfig.START_URL)

    internal fun freeBytes(): Long = try { StatFs(filesDir.path).availableBytes } catch (_: Exception) { 0L }

    internal fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast("پیوند باز نشد") }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LibraryScreen(activity: LibraryActivity) {
    val repo = AppGraph.repo
    val scope = rememberCoroutineScope()
    val account by AppGraph.session.account.collectAsState()
    val online by AppGraph.connectivity.online.collectAsState()
    val wifiOnly by AppGraph.prefs.wifiOnly.collectAsState()
    val all by remember { repo.observeAll() }.collectAsState(initial = null)
    val used by remember { repo.observeUsedBytes() }.collectAsState(initial = 0L)
    val owner = account?.ownerKey
    val progressFlow = remember(owner) { repo.observeProgress(owner ?: "") }
    val progress by progressFlow.collectAsState(initial = emptyList())
    val watched = remember(progress) { progress.associate { it.videoKey to (if (it.durationMs > 0) it.positionMs.toFloat() / it.durationMs else 0f) } }
    var free by remember { mutableLongStateOf(activity.freeBytes()) }
    LaunchedEffect(used) { free = activity.freeBytes() }

    var confirmDelete by remember { mutableStateOf<List<DownloadEntity>?>(null) }
    var updateDialog by remember { mutableStateOf<UpdateDecision?>(null) }

    val mine = all.orEmpty().filter { owner != null && it.ownerKey == owner }
    val others = all.orEmpty().filter { owner == null || it.ownerKey != owner }

    Column(Modifier.fillMaxSize().background(ShipaaColors.background).systemBarsPadding()) {
        // Header — same structure as the site: title + short description, back on the start side.
        Row(
            Modifier.fillMaxWidth().background(ShipaaColors.surface).padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { activity.finish() }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = ShipaaColors.ink)
            }
            Column(Modifier.weight(1f)) {
                Text("ویدئوهای ذخیره‌شده", style = MaterialTheme.typography.titleMedium, color = ShipaaColors.ink)
                Text("قابل تماشا بدون اینترنت، فقط داخل اپ شیپا", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
            }
            if (!online) {
                Row(
                    Modifier.padding(end = 12.dp).clip(RoundedCornerShape(DesignTokens.Radius.chip.dp))
                        .background(ShipaaColors.warningSoft).padding(horizontal = 10.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.WifiOff, null, tint = ShipaaColors.warning, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("آفلاین", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.warning)
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(ShipaaColors.line))

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(DesignTokens.Space.md.dp),
            verticalArrangement = Arrangement.spacedBy(DesignTokens.Space.sm.dp),
        ) {
            item { StoragePanel(used, free) }

            when {
                all == null -> Unit
                owner == null -> item {
                    MessageState(
                        icon = Icons.Rounded.Lock,
                        title = "برای دیدن ذخیره‌ها وارد حساب شوید",
                        body = "ویدئوهای ذخیره‌شده به حساب کاربری شما در شیپا گره خورده‌اند تا روی گوشی مشترک امن بمانند.",
                    ) { if (online) ShipaaButton("ورود به حساب", activity::openSite, kind = ButtonKind.PRIMARY) }
                }
                mine.isEmpty() -> item {
                    MessageState(
                        icon = Icons.Rounded.VideoLibrary,
                        title = "هنوز ویدئویی ذخیره نکرده‌اید",
                        body = "در صفحه هر جلسه، زیر ویدئو دکمه «ذخیره برای آفلاین» را بزنید تا بدون اینترنت هم آن را ببینید.",
                    ) { if (online) ShipaaButton("رفتن به خانه یادگیری", activity::openSite, kind = ButtonKind.PRIMARY) }
                }
                else -> {
                    mine.groupBy { it.course.ifBlank { "سایر جلسات" } }.forEach { (course, list) ->
                        item(key = "h-$course") {
                            Text(course, style = MaterialTheme.typography.titleSmall, color = ShipaaColors.muted,
                                modifier = Modifier.padding(top = DesignTokens.Space.xs.dp, start = 4.dp))
                        }
                        items(list, key = { it.id }) { e ->
                            DownloadCard(
                                e = e,
                                watched = watched[e.id] ?: 0f,
                                online = online,
                                onPlay = { activity.play(e) },
                                onPause = { scope.launch { AppGraph.scheduler.pause(e.id) } },
                                onResume = {
                                    scope.launch {
                                        if (e.errorEnum == DownloadError.KEY_LOST) {
                                            AppGraph.scheduler.delete(e.id)
                                            AppGraph.scheduler.enqueue(VideoInfo(e.videoUrl, e.title, e.course, e.lessonId, e.pageUrl, e.poster), owner)
                                        } else AppGraph.scheduler.resume(e.id)
                                    }
                                },
                                onVerify = {
                                    scope.launch {
                                        when (LicenseVerifier.verify(repo, e)) {
                                            AccessCheck.GRANTED -> activity.toast("تأیید شد؛ تا ۳۰ روز آفلاین قابل تماشاست")
                                            AccessCheck.REVOKED -> activity.toast("دسترسی شما به این جلسه فعال نیست")
                                            AccessCheck.LOGGED_OUT -> activity.toast("ابتدا در سایت وارد حساب شوید")
                                            AccessCheck.UNKNOWN -> { activity.toast("صفحه جلسه باز می‌شود تا دسترسی تأیید شود"); activity.openLesson(e) }
                                        }
                                    }
                                },
                                onDelete = { confirmDelete = listOf(e) },
                                onOpenLesson = { activity.openLesson(e) },
                            )
                        }
                    }
                }
            }

            if (others.isNotEmpty()) item {
                Panel {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "${PersianFormat.number(others.size)} ویدئوی دیگر روی این گوشی متعلق به حساب دیگری است (${PersianFormat.bytes(others.sumOf { it.downloadedBytes })}).",
                            style = MaterialTheme.typography.bodySmall, color = ShipaaColors.muted,
                        )
                        ShipaaButton("حذف آن‌ها از گوشی", { confirmDelete = others }, kind = ButtonKind.DANGER, icon = Icons.Rounded.Delete)
                    }
                }
            }

            item {
                Panel {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("تنظیمات", style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink)
                        Row(
                            Modifier.fillMaxWidth().clickable(role = Role.Switch) { AppGraph.prefs.setWifiOnly(!wifiOnly) },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("دانلود فقط با وای‌فای", style = MaterialTheme.typography.bodyMedium, color = ShipaaColors.ink)
                                Text("برای صرفه‌جویی در اینترنت همراه", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
                            }
                            Switch(
                                checked = wifiOnly,
                                onCheckedChange = { AppGraph.prefs.setWifiOnly(it) },
                                colors = SwitchDefaults.colors(checkedTrackColor = ShipaaColors.primary),
                            )
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (mine.isNotEmpty()) {
                                ShipaaButton("حذف همه ذخیره‌ها", { confirmDelete = mine }, kind = ButtonKind.DANGER, icon = Icons.Rounded.Delete)
                            }
                            ShipaaButton("بررسی به‌روزرسانی", {
                                scope.launch { updateDialog = UpdateChecker.check(AppGraph.prefs, force = true) }
                            }, icon = Icons.Rounded.SystemUpdate, enabled = online)
                        }
                        Text(
                            "نسخه ${PersianFormat.digits(BuildConfig.VERSION_NAME)} · مجوز تماشای آفلاین هر جلسه ${PersianFormat.number(BuildConfig.LICENSE_DAYS)} روز پس از آخرین اتصال",
                            style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted,
                        )
                    }
                }
            }
        }
    }

    confirmDelete?.let { targets ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(if (targets.size == 1) "حذف ویدئو از گوشی؟" else "حذف ${PersianFormat.number(targets.size)} ویدئو از گوشی؟") },
            text = { Text("فایل ذخیره‌شده پاک می‌شود و ${PersianFormat.bytes(targets.sumOf { it.downloadedBytes })} فضا آزاد می‌شود. دسترسی شما به دوره در سایت تغییری نمی‌کند.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    scope.launch { AppGraph.scheduler.deleteAll(targets.map { it.id }); activity.toast("حذف شد") }
                }) { Text("حذف", color = ShipaaColors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("انصراف", color = ShipaaColors.primary) } },
            containerColor = ShipaaColors.surface,
            shape = RoundedCornerShape(DesignTokens.Radius.panel.dp),
        )
    }

    updateDialog?.let { d ->
        when (d) {
            UpdateDecision.UpToDate -> { LaunchedEffect(d) { activity.toast("نسخه شما به‌روز است"); updateDialog = null } }
            is UpdateDecision.Optional, is UpdateDecision.Required -> {
                val m = if (d is UpdateDecision.Optional) d.manifest else (d as UpdateDecision.Required).manifest
                AlertDialog(
                    onDismissRequest = { updateDialog = null },
                    title = { Text("نسخه ${PersianFormat.digits(m.versionName)} آماده است") },
                    text = { Text(m.notes.ifBlank { "برای بهترین تجربه، نسخه جدید را نصب کنید." }) },
                    confirmButton = { TextButton(onClick = { updateDialog = null; activity.openUrl(m.downloadUrl) }) { Text("دریافت", color = ShipaaColors.primary) } },
                    dismissButton = { TextButton(onClick = { updateDialog = null }) { Text("بعداً", color = ShipaaColors.muted) } },
                    containerColor = ShipaaColors.surface,
                )
            }
        }
    }
}

@Composable
private fun StoragePanel(used: Long, free: Long) {
    Panel {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.SdStorage, contentDescription = null, tint = ShipaaColors.primary)
                Spacer(Modifier.width(8.dp))
                Text("حافظه گوشی", style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink, modifier = Modifier.weight(1f))
                Text("${PersianFormat.bytes(free)} خالی", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
            }
            val fraction = if (used + free > 0) used.toFloat() / (used + free) else 0f
            ProgressLine(fraction.coerceAtLeast(if (used > 0) 0.02f else 0f), color = ShipaaColors.grass)
            Text("ویدئوهای شیپا: ${PersianFormat.bytes(used)}", style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DownloadCard(
    e: DownloadEntity,
    watched: Float,
    online: Boolean,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onVerify: () -> Unit,
    onDelete: () -> Unit,
    onOpenLesson: () -> Unit,
) {
    val state = e.stateEnum
    CardBox(Modifier.clickable(enabled = state == DownloadState.COMPLETED, role = Role.Button, onClick = onPlay)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(DesignTokens.Radius.card.dp))
                        .background(if (state == DownloadState.COMPLETED) ShipaaColors.successSoft else ShipaaColors.surfaceMuted),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (state == DownloadState.COMPLETED) Icons.Rounded.PlayArrow else Icons.Rounded.Download,
                        contentDescription = null,
                        tint = if (state == DownloadState.COMPLETED) ShipaaColors.primary else ShipaaColors.muted,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(e.title, style = MaterialTheme.typography.titleSmall, color = ShipaaColors.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val size = if (e.totalBytes > 0) PersianFormat.bytes(e.totalBytes) else "حجم نامشخص"
                    val seen = if (watched > 0.01f) " · ${PersianFormat.percent((watched * 100).toInt())} دیده‌شده" else ""
                    Text(size + seen, style = MaterialTheme.typography.labelMedium, color = ShipaaColors.muted)
                    StatusChip(state, e.errorEnum, e.percent)
                }
            }
            when (state) {
                DownloadState.DOWNLOADING, DownloadState.QUEUED, DownloadState.WAITING_NETWORK, DownloadState.PAUSED, DownloadState.FAILED ->
                    if (e.totalBytes > 0) ProgressLine(e.downloadedBytes.toFloat() / e.totalBytes,
                        color = if (state == DownloadState.DOWNLOADING) ShipaaColors.sky else ShipaaColors.warning)
                DownloadState.COMPLETED -> if (watched > 0.01f) ProgressLine(watched, color = ShipaaColors.grass)
                else -> Unit
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (state) {
                    DownloadState.COMPLETED -> ShipaaButton("پخش", onPlay, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.PlayArrow)
                    DownloadState.DOWNLOADING, DownloadState.QUEUED, DownloadState.WAITING_NETWORK ->
                        ShipaaButton("توقف دانلود", onPause, icon = Icons.Rounded.Pause)
                    DownloadState.PAUSED -> ShipaaButton("ادامه دانلود", onResume, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Download, enabled = online)
                    DownloadState.FAILED -> ShipaaButton(
                        if (e.errorEnum == DownloadError.KEY_LOST) "دانلود دوباره" else "تلاش دوباره",
                        onResume, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.Refresh, enabled = online,
                    )
                    DownloadState.NEEDS_VERIFICATION -> ShipaaButton("تأیید با اینترنت", onVerify, kind = ButtonKind.PRIMARY, icon = Icons.Rounded.VerifiedUser, enabled = online)
                    DownloadState.LOCKED -> Unit
                }
                if (e.pageUrl.isNotBlank() && online) ShipaaButton("صفحه جلسه", onOpenLesson, icon = Icons.Rounded.Link)
                ShipaaButton("حذف", onDelete, kind = ButtonKind.DANGER, icon = Icons.Rounded.Delete)
            }
        }
    }
}

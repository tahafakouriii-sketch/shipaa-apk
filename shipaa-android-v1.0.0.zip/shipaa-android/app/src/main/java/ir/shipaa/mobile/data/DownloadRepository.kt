package ir.shipaa.mobile.data

import ir.shipaa.mobile.core.bridge.VideoInfo
import ir.shipaa.mobile.core.crypto.CtrStreamCipher
import ir.shipaa.mobile.core.crypto.EncryptedVideoFile
import ir.shipaa.mobile.core.download.DownloadAction
import ir.shipaa.mobile.core.download.DownloadError
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.download.DownloadStateMachine
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.core.progress.ProgressPolicy
import ir.shipaa.mobile.core.progress.WatchProgress
import ir.shipaa.mobile.core.video.VideoUrlPolicy
import ir.shipaa.mobile.crypto.KeyVault
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/** Single owner of download rows, encrypted files and watch progress. */
class DownloadRepository(
    private val db: AppDatabase,
    private val videosDir: File,
    private val prefs: AppPrefs,
    val licensePolicy: LicensePolicy,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val dao = db.downloads()
    private val progressDao = db.progress()
    private val lock = Mutex()

    fun observeAll(): Flow<List<DownloadEntity>> = dao.observeAll()
    fun observe(id: String): Flow<DownloadEntity?> = dao.observe(id)
    fun observeUsedBytes(): Flow<Long> = dao.observeUsedBytes()
    suspend fun get(id: String): DownloadEntity? = dao.get(id)
    suspend fun all(): List<DownloadEntity> = dao.all()

    fun fileFor(e: DownloadEntity): File = File(videosDir, e.fileName)

    /** Opens the encrypted file of [e]. Throws when the device key cannot unwrap the file key. */
    fun encryptedFile(e: DownloadEntity): EncryptedVideoFile {
        val key = KeyVault.unwrap(e.wrappedKey)
        return EncryptedVideoFile(fileFor(e), CtrStreamCipher(key, KeyVault.decodeNonce(e.nonce)))
    }

    /**
     * Creates or re-queues a download for [video] on behalf of [ownerKey].
     * Returns the row id and whether a worker should be scheduled.
     */
    suspend fun requestDownload(video: VideoInfo, ownerKey: String): Pair<String, Boolean> = lock.withLock {
        val id = VideoUrlPolicy.keyOf(video.src)
        val now = clock()
        val existing = dao.get(id)
        if (existing == null) {
            val nonce = CtrStreamCipher.newNonce()
            dao.insert(
                DownloadEntity(
                    id = id, videoUrl = video.src, pageUrl = video.pageUrl, lessonId = video.lessonId,
                    title = video.title, course = video.course, poster = video.poster, ownerKey = ownerKey,
                    state = DownloadState.QUEUED.name, error = null, totalBytes = 0, downloadedBytes = 0,
                    etag = null, lastModified = null, fileName = "$id.shv",
                    wrappedKey = KeyVault.wrap(CtrStreamCipher.newKey()), nonce = KeyVault.encodeNonce(nonce),
                    createdAt = now, updatedAt = now, verifiedAt = now,
                )
            )
            return id to true
        }
        // The request comes from a lesson page the user can see right now, which proves access:
        // claim the file for this account and refresh the licence.
        var state = existing.stateEnum
        if (state == DownloadState.LOCKED || state == DownloadState.NEEDS_VERIFICATION) state = DownloadState.COMPLETED
        state = DownloadStateMachine.next(state, DownloadAction.ENQUEUE)
        dao.upsert(
            existing.copy(
                ownerKey = ownerKey, state = state.name, error = if (state == DownloadState.QUEUED) null else existing.error,
                title = video.title.ifBlank { existing.title }, course = video.course.ifBlank { existing.course },
                pageUrl = video.pageUrl.ifBlank { existing.pageUrl }, lessonId = video.lessonId ?: existing.lessonId,
                poster = video.poster ?: existing.poster, videoUrl = video.src, updatedAt = now, verifiedAt = now,
            )
        )
        id to state.isActive
    }

    suspend fun transition(id: String, action: DownloadAction, error: DownloadError? = null): DownloadEntity? = lock.withLock {
        val e = dao.get(id) ?: return null
        val next = DownloadStateMachine.next(e.stateEnum, action)
        if (next == e.stateEnum && error == null) return e
        val updated = e.copy(
            state = next.name,
            error = when {
                error != null && next != e.stateEnum -> error.name
                next == DownloadState.COMPLETED || next == DownloadState.DOWNLOADING || next == DownloadState.QUEUED -> null
                else -> e.error
            },
            updatedAt = clock(),
            verifiedAt = if (action == DownloadAction.COMPLETE || action == DownloadAction.VERIFIED) clock() else e.verifiedAt,
        )
        dao.upsert(updated)
        updated
    }

    suspend fun saveValidators(id: String, total: Long, etag: String?, lastModified: String?) {
        lock.withLock {
            dao.get(id)?.let { dao.upsert(it.copy(totalBytes = total, etag = etag, lastModified = lastModified, updatedAt = clock())) }
        }
    }

    suspend fun updateProgress(id: String, bytes: Long, total: Long) = dao.updateProgress(id, bytes, total, clock())

    /** Removes the row, the encrypted file and therefore the only copy of its key. */
    suspend fun delete(id: String) {
        lock.withLock {
            dao.get(id)?.let { fileFor(it).delete() }
            dao.delete(id)
        }
    }

    /** Marks videos seen on a lesson page as verified (the page itself proves access). */
    suspend fun markSeenOnPage(videoUrls: Collection<String>, ownerKey: String) {
        if (videoUrls.isEmpty()) return
        lock.withLock { markSeenLocked(videoUrls, ownerKey) }
    }

    private suspend fun markSeenLocked(videoUrls: Collection<String>, ownerKey: String) {
        val now = clock()
        dao.getAll(videoUrls.map(VideoUrlPolicy::keyOf)).forEach { e ->
            val revived = when (e.stateEnum) {
                DownloadState.NEEDS_VERIFICATION, DownloadState.LOCKED -> DownloadState.COMPLETED
                else -> e.stateEnum
            }
            dao.upsert(e.copy(ownerKey = ownerKey, verifiedAt = now, state = revived.name,
                error = if (revived == DownloadState.COMPLETED) null else e.error, updatedAt = now))
        }
    }

    /** The site confirmed access again: extend the offline licence. */
    suspend fun markVerified(id: String) {
        val e = get(id) ?: return
        if (e.stateEnum == DownloadState.NEEDS_VERIFICATION) transition(id, DownloadAction.VERIFIED)
        else if (e.stateEnum == DownloadState.COMPLETED) lock.withLock {
            dao.get(id)?.let { dao.upsert(it.copy(verifiedAt = clock(), updatedAt = clock())) }
        }
    }

    /** Marks a stored file as unusable regardless of state (e.g. its key can no longer be unwrapped). */
    suspend fun markBroken(id: String, error: DownloadError) {
        lock.withLock {
            dao.get(id)?.let { dao.upsert(it.copy(state = DownloadState.FAILED.name, error = error.name, updatedAt = clock())) }
        }
    }

    /** The site no longer gives this account access to the lesson. */
    suspend fun revoke(id: String) { transition(id, DownloadAction.LOCK, DownloadError.ACCESS_REVOKED) }

    /** Licence state for playback, also persisting expiry so the library shows it. */
    suspend fun licenseVerdict(e: DownloadEntity): LicensePolicy.Verdict {
        val now = clock()
        val verdict = licensePolicy.evaluate(now, e.verifiedAt, prefs.lastSeenAt)
        prefs.lastSeenAt = licensePolicy.advanceLastSeen(prefs.lastSeenAt, now)
        if ((verdict == LicensePolicy.Verdict.EXPIRED || verdict == LicensePolicy.Verdict.CLOCK_TAMPERED) &&
            e.stateEnum == DownloadState.COMPLETED) {
            transition(e.id, DownloadAction.LICENSE_EXPIRED)
        }
        return verdict
    }

    // ---- Watch progress ----

    suspend fun progress(owner: String, videoKey: String): WatchProgress? =
        progressDao.get(owner, videoKey)?.let { WatchProgress(it.videoKey, it.positionMs, it.durationMs, it.updatedAt) }

    fun observeProgress(owner: String): Flow<List<ProgressEntity>> = progressDao.observeForOwner(owner)

    suspend fun saveProgress(owner: String, videoKey: String, videoUrl: String, positionMs: Long, durationMs: Long) {
        if (durationMs <= 0 && positionMs <= 0) return
        progressDao.upsert(ProgressEntity(owner, videoKey, videoUrl, positionMs.coerceAtLeast(0), durationMs.coerceAtLeast(0), clock(), dirty = true))
    }

    suspend fun dirtyProgress(owner: String) = progressDao.dirty(owner)

    /** Applies server values with the merge rule; local rows edited after [sentAt] stay dirty. */
    suspend fun applyRemoteProgress(owner: String, remote: List<WatchProgress>, sentKeys: List<String>, sentAt: Long) {
        val merged = remote.mapNotNull { r ->
            val local = progressDao.get(owner, r.videoKey)
            val localP = local?.let { WatchProgress(it.videoKey, it.positionMs, it.durationMs, it.updatedAt) }
            val winner = ProgressPolicy.merge(localP, r) ?: return@mapNotNull null
            if (winner == localP) null
            else ProgressEntity(owner, r.videoKey, local?.videoUrl ?: "", winner.positionMs, winner.durationMs, winner.updatedAt, dirty = false)
        }
        if (merged.isNotEmpty()) progressDao.upsertAll(merged)
        if (sentKeys.isNotEmpty()) progressDao.markClean(owner, sentKeys, sentAt)
    }
}

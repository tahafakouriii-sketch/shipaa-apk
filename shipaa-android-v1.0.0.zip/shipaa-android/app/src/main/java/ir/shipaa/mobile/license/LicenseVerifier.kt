package ir.shipaa.mobile.license

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import ir.shipaa.mobile.AppGraph
import ir.shipaa.mobile.core.download.DownloadState
import ir.shipaa.mobile.core.license.AccessCheck
import ir.shipaa.mobile.core.license.LessonAccessVerifier
import ir.shipaa.mobile.core.license.LicensePolicy
import ir.shipaa.mobile.data.DownloadEntity
import ir.shipaa.mobile.data.DownloadRepository
import ir.shipaa.mobile.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Asks shipaa.ir (with the user's session) whether a stored lesson is still accessible. */
object LicenseVerifier {
    private const val MAX_HTML = 4_000_000

    suspend fun check(e: DownloadEntity): AccessCheck = withContext(Dispatchers.IO) {
        if (e.pageUrl.isBlank()) return@withContext AccessCheck.UNKNOWN
        val request = Request.Builder().url(e.pageUrl).header("Accept", "text/html").build()
        try {
            Http.client().newCall(request).execute().use { r ->
                val html = r.body?.string()?.take(MAX_HTML) ?: ""
                LessonAccessVerifier.decide(r.code, r.request.url.toString(), html, e.videoUrl.substringBefore('?'))
            }
        } catch (_: IOException) {
            AccessCheck.UNKNOWN
        } catch (_: IllegalArgumentException) {
            AccessCheck.UNKNOWN
        }
    }

    /** Checks and records the result. */
    suspend fun verify(repo: DownloadRepository, e: DownloadEntity): AccessCheck {
        val result = check(e)
        when (result) {
            AccessCheck.GRANTED -> repo.markVerified(e.id)
            AccessCheck.REVOKED -> repo.revoke(e.id)
            AccessCheck.LOGGED_OUT, AccessCheck.UNKNOWN -> Unit
        }
        return result
    }
}

/** Daily background refresh of offline licences, so they rarely expire for active learners. */
class LicenseWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        AppGraph.ensure(applicationContext)
        if (!AppGraph.connectivity.currentlyOnline()) return Result.success()
        val repo = AppGraph.repo
        val now = System.currentTimeMillis()
        repo.all().filter { it.stateEnum == DownloadState.COMPLETED || it.stateEnum == DownloadState.NEEDS_VERIFICATION }
            .forEach { e ->
                val verdict = repo.licensePolicy.evaluate(now, e.verifiedAt, AppGraph.prefs.lastSeenAt)
                if (verdict != LicensePolicy.Verdict.VALID || e.stateEnum == DownloadState.NEEDS_VERIFICATION) {
                    LicenseVerifier.verify(repo, e)
                }
            }
        return Result.success()
    }

    companion object {
        private const val NAME = "licence-refresh"

        fun schedulePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<LicenseWorker>(1, TimeUnit.DAYS).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}

package ir.shipaa.mobile.core

import ir.shipaa.mobile.core.design.DesignTokens
import org.junit.Test
import java.io.File
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** colors.xml (used before Compose starts: window background, launcher) must match DesignTokens. */
class DesignTokensResourceTest {
    private fun resFile(rel: String): File =
        listOf(File("src/main/res/$rel"), File("app/src/main/res/$rel"))
            .first { it.exists() }

    @Test fun xmlColorsMatchTokens() {
        val xml = resFile("values/colors.xml").readText()
        fun color(name: String) = Regex("""<color name="$name">(#[0-9A-Fa-f]{6})</color>""").find(xml)!!.groupValues[1].uppercase()
        assertEquals(DesignTokens.hex(DesignTokens.Color.primary), color("shp_primary"))
        assertEquals(DesignTokens.hex(DesignTokens.Color.background), color("shp_background"))
        assertEquals(DesignTokens.hex(DesignTokens.Color.surface), color("shp_surface"))
        assertEquals(DesignTokens.hex(DesignTokens.Color.ink), color("shp_ink"))
        assertEquals(DesignTokens.hex(DesignTokens.Color.playerBackground), color("shp_player_background"))
    }

    @Test fun bridgeScriptIsInAssetsAndUsesTokenVariables() {
        val js = listOf(File("src/main/assets/bridge.js"), File("app/src/main/assets/bridge.js"))
            .first { it.exists() }.readText()
        assertTrue(js.contains("window.__SHP_TOKENS__"))
        // Every CSS variable used by the injected UI must be defined by DesignTokens.toCss().
        val css = DesignTokens.toCss()
        Regex("""var\((--shp-[a-z-]+)""").findAll(js).map { it.groupValues[1] }.toSet().forEach {
            assertTrue(css.contains("$it:"), "token $it used in bridge.js is not defined")
        }
    }
}

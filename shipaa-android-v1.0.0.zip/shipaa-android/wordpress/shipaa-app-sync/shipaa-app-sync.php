<?php
/**
 * Plugin Name: Shipaa App Sync (اختیاری)
 * Plugin URI:  https://shipaa.ir/
 * Description: همراه اختیاری اپ اندروید شیپا: همگام‌سازی موقعیت تماشای جلسات برای هر کاربر. به استادیار، جلسات، ووکامرس یا افزونه‌های دیگر دست نمی‌زند و برای کاربران وب هیچ تغییری ایجاد نمی‌کند.
 * Version:     1.0.0
 * Author:      SHIPAA
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * Text Domain: shipaa-app-sync
 */

if (!defined('ABSPATH')) {
    exit;
}

const SHIPAA_APP_SYNC_VERSION = '1.0.0';
const SHIPAA_APP_SYNC_META = 'shipaa_app_progress';
const SHIPAA_APP_SYNC_NONCE = 'shipaa_app_sync';
const SHIPAA_APP_SYNC_MAX_ENTRIES = 2000;
const SHIPAA_APP_SYNC_MAX_ITEMS_PER_REQUEST = 200;
const SHIPAA_APP_SYNC_MAX_BODY = 200000;

/** Requests from the Android app carry "ShipaaApp/<version>" in the User-Agent. */
function shipaa_app_sync_is_app_request(): bool
{
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
    return strpos($ua, 'ShipaaApp/') !== false;
}

/** Gives the app a nonce on pages it loads. Nothing is printed for normal browsers. */
add_action('wp_head', function () {
    if (!is_user_logged_in() || !shipaa_app_sync_is_app_request()) {
        return;
    }
    echo '<meta name="shipaa-app-sync" content="' . esc_attr(wp_create_nonce(SHIPAA_APP_SYNC_NONCE)) . '">' . "\n";
}, 1);

add_action('wp_ajax_shipaa_app_progress_sync', 'shipaa_app_sync_handle');
add_action('wp_ajax_nopriv_shipaa_app_progress_sync', function () {
    wp_send_json_error(['code' => 'not_logged_in'], 401);
});

/**
 * Merges the posted watch positions into the user's stored positions and returns them all.
 * Rule (same as the app): newest update wins; on a tie the further position wins.
 *
 * Request:  items = JSON [{"k": 32-hex video key, "p": position ms, "d": duration ms, "t": updated ms}]
 * Response: {"success": true, "data": {"items": [...]}}
 */
function shipaa_app_sync_handle()
{
    if (!check_ajax_referer(SHIPAA_APP_SYNC_NONCE, '_ajax_nonce', false)) {
        wp_send_json_error(['code' => 'bad_nonce'], 403);
    }
    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(['code' => 'not_logged_in'], 401);
    }

    $raw = isset($_POST['items']) ? (string) wp_unslash($_POST['items']) : '[]';
    if (strlen($raw) > SHIPAA_APP_SYNC_MAX_BODY) {
        wp_send_json_error(['code' => 'too_large'], 413);
    }
    $items = json_decode($raw, true);
    if (!is_array($items)) {
        $items = [];
    }

    $store = shipaa_app_sync_merge(
        get_user_meta($user_id, SHIPAA_APP_SYNC_META, true),
        $items,
        (int) round(microtime(true) * 1000)
    );
    update_user_meta($user_id, SHIPAA_APP_SYNC_META, $store);

    $out = [];
    foreach ($store as $key => $v) {
        $out[] = ['k' => (string) $key, 'p' => $v['p'], 'd' => $v['d'], 't' => $v['t']];
    }
    wp_send_json_success(['items' => $out]);
}

/**
 * Pure merge function (unit-tested in tests/run-tests.php).
 *
 * @param mixed $store  previously stored map key => ['p','d','t'] (anything else is treated as empty)
 * @param array $items  decoded request items
 * @param int   $now_ms server time in milliseconds
 * @return array<string, array{p:int,d:int,t:int}>
 */
function shipaa_app_sync_merge($store, array $items, int $now_ms): array
{
    if (!is_array($store)) {
        $store = [];
    }
    foreach (array_slice($items, 0, SHIPAA_APP_SYNC_MAX_ITEMS_PER_REQUEST) as $it) {
        if (!is_array($it)) {
            continue;
        }
        $key = isset($it['k']) ? (string) $it['k'] : '';
        if (!preg_match('/^[0-9a-f]{32}$/', $key)) {
            continue;
        }
        $p = max(0, (int) ($it['p'] ?? 0));
        $d = max(0, (int) ($it['d'] ?? 0));
        $t = (int) ($it['t'] ?? 0);
        if ($t <= 0 || $t > $now_ms + 86400000) {
            $t = $now_ms; // a device clock far in the future must not win forever
        }
        if ($d > 0 && $p > $d) {
            $p = $d;
        }
        $cur = isset($store[$key]) && is_array($store[$key]) ? $store[$key] : null;
        if ($cur === null || $t > (int) $cur['t'] || ($t === (int) $cur['t'] && $p > (int) $cur['p'])) {
            $store[$key] = ['p' => $p, 'd' => $d, 't' => $t];
        }
    }
    if (count($store) > SHIPAA_APP_SYNC_MAX_ENTRIES) {
        uasort($store, function ($a, $b) {
            return (int) $b['t'] <=> (int) $a['t'];
        });
        $store = array_slice($store, 0, SHIPAA_APP_SYNC_MAX_ENTRIES, true);
    }
    return $store;
}

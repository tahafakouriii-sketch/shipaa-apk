<?php
// Standalone tests with minimal WordPress stubs: php wordpress/shipaa-app-sync/tests/run-tests.php
declare(strict_types=1);

define('ABSPATH', __DIR__);
$GLOBALS['actions'] = [];
$GLOBALS['meta'] = [];
$GLOBALS['logged_in'] = 0;
$GLOBALS['nonce_ok'] = true;

class JsonExit extends Exception
{
    public $payload;
    public $status;
    public function __construct($payload, $status)
    {
        parent::__construct('json');
        $this->payload = $payload;
        $this->status = $status;
    }
}

function add_action($hook, $cb, $prio = 10) { $GLOBALS['actions'][$hook][] = $cb; }
function is_user_logged_in() { return $GLOBALS['logged_in'] > 0; }
function get_current_user_id() { return $GLOBALS['logged_in']; }
function wp_create_nonce($a) { return 'n0nce' . $a; }
function esc_attr($s) { return htmlspecialchars((string) $s, ENT_QUOTES); }
function check_ajax_referer($a, $q, $die) { return $GLOBALS['nonce_ok']; }
function wp_unslash($s) { return $s; }
function get_user_meta($u, $k, $single) { return $GLOBALS['meta'][$u][$k] ?? ''; }
function update_user_meta($u, $k, $v) { $GLOBALS['meta'][$u][$k] = $v; return true; }
function wp_send_json_success($d) { throw new JsonExit(['success' => true, 'data' => $d], 200); }
function wp_send_json_error($d, $s = 400) { throw new JsonExit(['success' => false, 'data' => $d], $s); }

require __DIR__ . '/../shipaa-app-sync.php';

$failures = 0;
$count = 0;
function check($cond, $msg) {
    global $failures, $count;
    $count++;
    if (!$cond) { $failures++; echo "FAIL: $msg\n"; } else { echo "PASS: $msg\n"; }
}
function call_ajax(array $post) {
    $_POST = $post;
    try { shipaa_app_sync_handle(); } catch (JsonExit $e) { return $e; }
    return null;
}

$k1 = str_repeat('a', 32);
$k2 = str_repeat('b', 32);
$now = 1800000000000;

// merge rules
$s = shipaa_app_sync_merge('', [['k' => $k1, 'p' => 1000, 'd' => 5000, 't' => 10]], $now);
check($s[$k1] === ['p' => 1000, 'd' => 5000, 't' => 10], 'stores a new position');
$s = shipaa_app_sync_merge($s, [['k' => $k1, 'p' => 200, 'd' => 5000, 't' => 20]], $now);
check($s[$k1]['p'] === 200, 'newer update wins even if position is smaller (user rewound)');
$s = shipaa_app_sync_merge($s, [['k' => $k1, 'p' => 4000, 'd' => 5000, 't' => 5]], $now);
check($s[$k1]['p'] === 200, 'older update is ignored');
$s = shipaa_app_sync_merge($s, [['k' => $k1, 'p' => 300, 'd' => 5000, 't' => 20]], $now);
check($s[$k1]['p'] === 300, 'tie: further position wins');
$s = shipaa_app_sync_merge($s, [['k' => 'BAD', 'p' => 1], ['k' => $k2 . 'x'], 'junk', ['k' => $k2, 'p' => -5, 'd' => 10, 't' => 1]], $now);
check(!isset($s['BAD']) && count($s) === 2 && $s[$k2]['p'] === 0, 'rejects bad keys, clamps negatives');
$s = shipaa_app_sync_merge([], [['k' => $k1, 'p' => 9000, 'd' => 5000, 't' => $now * 2]], $now);
check($s[$k1]['t'] === $now && $s[$k1]['p'] === 5000, 'future timestamps clamped, position <= duration');
$many = [];
for ($i = 0; $i < 2100; $i++) { $many[sprintf('%032x', $i)] = ['p' => 1, 'd' => 2, 't' => $i + 1]; }
$s = shipaa_app_sync_merge($many, [], $now);
check(count($s) === 2000 && isset($s[sprintf('%032x', 2099)]) && !isset($s[sprintf('%032x', 0)]), 'keeps the 2000 most recent entries');
$items = [];
for ($i = 0; $i < 300; $i++) { $items[] = ['k' => sprintf('%032x', $i), 'p' => 1, 'd' => 2, 't' => 3]; }
check(count(shipaa_app_sync_merge([], $items, $now)) === 200, 'at most 200 items per request');

// AJAX handler
$GLOBALS['logged_in'] = 7;
$r = call_ajax(['items' => json_encode([['k' => $k1, 'p' => 1500, 'd' => 6000, 't' => 100]])]);
check($r && $r->status === 200 && $r->payload['success'] && $r->payload['data']['items'][0]['k'] === $k1, 'ajax stores and returns items');
check($GLOBALS['meta'][7]['shipaa_app_progress'][$k1]['p'] === 1500, 'saved in user meta of the current user only');
$r = call_ajax(['items' => '{not json']);
check($r && $r->payload['success'] && count($r->payload['data']['items']) === 1, 'invalid JSON keeps existing data');
$r = call_ajax(['items' => str_repeat('x', 200001)]);
check($r && $r->status === 413, 'rejects oversized body');
$GLOBALS['nonce_ok'] = false;
$r = call_ajax(['items' => '[]']);
check($r && $r->status === 403 && $r->payload['data']['code'] === 'bad_nonce', 'bad nonce -> 403');
$GLOBALS['nonce_ok'] = true;
$GLOBALS['logged_in'] = 0;
$r = call_ajax(['items' => '[]']);
check($r && $r->status === 401, 'logged out -> 401');

// wp_head meta only for the app
$GLOBALS['logged_in'] = 7;
$head = $GLOBALS['actions']['wp_head'][0];
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 Chrome';
ob_start(); $head(); $out = ob_get_clean();
check($out === '', 'no meta tag for normal browsers');
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (Linux; Android 14) ShipaaApp/1.0.0';
ob_start(); $head(); $out = ob_get_clean();
check(strpos($out, 'name="shipaa-app-sync"') !== false && strpos($out, 'n0nceshipaa_app_sync') !== false, 'meta tag with nonce for the app');
$GLOBALS['logged_in'] = 0;
ob_start(); $head(); $out = ob_get_clean();
check($out === '', 'no meta tag when logged out');

echo "== " . ($count - $failures) . " passed, $failures failed\n";
exit($failures ? 1 : 0);

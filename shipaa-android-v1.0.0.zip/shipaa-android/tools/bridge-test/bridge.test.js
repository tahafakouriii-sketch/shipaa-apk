// Runs the real bridge.js inside a Studiare-like page (jsdom) and checks its contract.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const BRIDGE = fs.readFileSync(path.join(__dirname, '../../app/src/main/assets/bridge.js'), 'utf8');
const TOKENS = ':root{--shp-primary:#136B4B;}';

const LESSON_PAGE = `<!doctype html><html lang="fa" dir="rtl"><head><title>جلسه اول – شیپا</title>
<meta name="shipaa-app-sync" content="abc123def4"></head>
<body class="single single-studi_lesson postid-4821" style="font-family: IRANYekan, Tahoma">
  <nav class="woocommerce-breadcrumb"><a href="/">خانه</a><a href="/course/x/">دوره بازگشت به قدرت</a></nav>
  <header><button class="menu-toggle" aria-expanded="false" aria-controls="m">منو</button></header>
  <div class="mobile-menu" id="m"><a class="close">×</a></div>
  <h1 class="lesson-title">جلسه اول: مقدمه</h1>
  <div class="plyr"><video id="v1" poster="/p.jpg" src="https://dl.shipaa.ir/courses/x/lesson-01.mp4"></video></div>
  <video id="v2"><source src="https://evil.example/hack.mp4"></video>
  <p id="after">متن بعد از ویدئو</p>
</body></html>`;

async function load(html, { url = 'https://shipaa.ir/lesson/intro/', withNative = true } = {}) {
  const dom = new JSDOM(html, { url, runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  const sent = [];
  if (withNative) w.ShipaaNative = { postMessage: (s) => sent.push(JSON.parse(s)) };
  w.__SHP_TOKENS__ = TOKENS;
  // jsdom has no layout: treat elements as visible unless display:none.
  Object.defineProperty(w.HTMLElement.prototype, 'offsetParent', {
    get() { return this.style && this.style.display === 'none' ? null : this.parentNode; },
  });
  // Injected at document start, like WebViewCompat.addDocumentStartJavaScript.
  w.eval(BRIDGE);
  if (w.document.readyState === 'loading') await new Promise((r) => w.document.addEventListener('DOMContentLoaded', r));
  return { w, doc: w.document, sent };
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const byType = (sent, t) => sent.filter((m) => m.type === t);

test('reports hello and only allowed lesson videos with metadata', async () => {
  const { sent } = await load(LESSON_PAGE);
  const hello = byType(sent, 'hello')[0];
  assert.equal(hello.bridgeVersion, 1);
  assert.match(hello.fontFamily, /IRANYekan/);
  const videos = byType(sent, 'videos').at(-1).items;
  assert.equal(videos.length, 1, 'the non-Shipaa video must be ignored');
  const v = videos[0];
  assert.equal(v.src, 'https://dl.shipaa.ir/courses/x/lesson-01.mp4');
  assert.equal(v.title, 'جلسه اول: مقدمه');
  assert.equal(v.course, 'دوره بازگشت به قدرت');
  assert.equal(v.lessonId, 4821);
  assert.equal(v.pageUrl, 'https://shipaa.ir/lesson/intro/');
  assert.equal(v.poster, 'https://shipaa.ir/p.jpg');
  assert.deepEqual(byType(sent, 'syncNonce')[0], { type: 'syncNonce', nonce: 'abc123def4' });
});

test('inserts one action bar right after the player wrapper without touching the player', async () => {
  const { doc } = await load(LESSON_PAGE);
  const bars = doc.querySelectorAll('.shp-app-bar');
  assert.equal(bars.length, 1);
  const wrapper = doc.querySelector('.plyr');
  assert.equal(wrapper.nextElementSibling, bars[0]);
  assert.ok(wrapper.querySelector('#v1'), 'site video stays in its player');
  assert.equal(doc.querySelector('#v1').getAttribute('src'), 'https://dl.shipaa.ir/courses/x/lesson-01.mp4');
  const labels = [...bars[0].querySelectorAll('button')].map((b) => b.textContent);
  assert.deepEqual(labels, ['پخش در پلیر شیپا', 'ذخیره برای آفلاین', 'کتابخانه من']);
  assert.ok(doc.getElementById('shp-app-style').textContent.includes('--shp-primary:#136B4B'));
  // Running the script again must not duplicate anything.
  doc.defaultView.eval(BRIDGE);
  doc.defaultView.ShipaaApp.rescan();
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 1);
  assert.equal(doc.querySelectorAll('#shp-app-style').length, 1);
});

test('buttons send play / download / library messages', async () => {
  const { doc, sent } = await load(LESSON_PAGE);
  const [play, dl, lib] = doc.querySelectorAll('.shp-app-bar button');
  play.click(); dl.click(); lib.click();
  const p = byType(sent, 'play')[0];
  assert.equal(p.src, 'https://dl.shipaa.ir/courses/x/lesson-01.mp4');
  assert.equal(p.title, 'جلسه اول: مقدمه');
  assert.equal(byType(sent, 'download')[0].lessonId, 4821);
  assert.equal(byType(sent, 'openLibrary').length, 1);
});

test('renders native download states and maps taps to pause/resume', async () => {
  const { w, doc, sent } = await load(LESSON_PAGE);
  const src = 'https://dl.shipaa.ir/courses/x/lesson-01.mp4';
  const dl = () => doc.querySelectorAll('.shp-app-bar button')[1];

  w.ShipaaApp.onNative({ type: 'state', items: [{ src, state: 'DOWNLOADING', percent: 45, label: 'در حال دانلود', tone: 'PROGRESS' }] });
  assert.equal(dl().textContent, 'توقف دانلود ۴۵٪');
  assert.equal(doc.querySelector('.shp-app-chip').className, 'shp-app-chip PROGRESS');
  assert.equal(doc.querySelector('.shp-app-progress > i').style.width, '45%');
  dl().click();
  assert.deepEqual(byType(sent, 'pause').at(-1), { type: 'pause', src });

  w.ShipaaApp.onNative(JSON.stringify({ type: 'state', items: [{ src, state: 'PAUSED', percent: 45, label: 'متوقف', tone: 'WARNING' }] }));
  assert.equal(dl().textContent, 'ادامه دانلود ۴۵٪');
  dl().click();
  assert.deepEqual(byType(sent, 'resume').at(-1), { type: 'resume', src });

  w.ShipaaApp.onNative({ type: 'state', items: [{ src, state: 'COMPLETED', percent: 100, label: 'آماده پخش آفلاین', tone: 'SUCCESS' }] });
  assert.equal(dl().textContent, 'ذخیره‌شده — کتابخانه');
  assert.equal(doc.querySelector('.shp-app-progress'), null, 'no progress bar when complete');

  w.ShipaaApp.onNative({ type: 'state', items: [{ src }] }); // not stored any more
  assert.equal(dl().textContent, 'ذخیره برای آفلاین');
  w.ShipaaApp.onNative('not json'); // must not throw
});

test('labels are inserted as text, never as HTML', async () => {
  const { w, doc } = await load(LESSON_PAGE);
  const src = 'https://dl.shipaa.ir/courses/x/lesson-01.mp4';
  w.ShipaaApp.onNative({ type: 'state', items: [{ src, state: 'FAILED', label: '<img src=x onerror=alert(1)>', tone: 'DANGER' }] });
  assert.equal(doc.querySelectorAll('.shp-app-bar img').length, 0);
  assert.equal(doc.querySelector('.shp-app-chip').textContent, '<img src=x onerror=alert(1)>');
});

test('detects players added later (Studiare popups) and removes bars of removed videos', async () => {
  const { doc, sent } = await load(`<!doctype html><body class="postid-9"><div id="host"></div></body>`);
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 0);
  const box = doc.createElement('div');
  box.className = 'video-js';
  box.innerHTML = '<video><source src="https://dl.shipaa.ir/c/2.m4v?t=1"></video>';
  doc.getElementById('host').appendChild(box);
  await wait(400);
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 1);
  assert.equal(byType(sent, 'videos').at(-1).items[0].src, 'https://dl.shipaa.ir/c/2.m4v?t=1');
  box.remove();
  await wait(400);
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 0);
  assert.deepEqual(byType(sent, 'videos').at(-1).items, []);
});

test('back closes an open menu first, otherwise reports not handled', async () => {
  const { w, doc } = await load(LESSON_PAGE);
  let closed = 0;
  doc.querySelector('.mobile-menu .close').addEventListener('click', () => { closed++; doc.querySelector('.mobile-menu').classList.remove('active'); });
  assert.equal(w.ShipaaApp.handleBack(), false, 'menu closed: nothing to handle');
  doc.querySelector('.mobile-menu').classList.add('active');
  assert.equal(w.ShipaaApp.handleBack(), true);
  assert.equal(closed, 1);
  assert.equal(w.ShipaaApp.handleBack(), false);
});

test('works without the native object (plain browser) and never throws', async () => {
  const { doc } = await load(LESSON_PAGE, { withNative: false });
  assert.equal(doc.querySelectorAll('.shp-app-bar').length, 1);
  doc.querySelectorAll('.shp-app-bar button').forEach((b) => b.click());
});
